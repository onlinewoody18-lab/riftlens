// Build planner: given a champion, role and keystone, assemble the best rune page and
// item path from collected ranked games, and compare every rune option side by side.
//
// "Best" depends on mode:
//   winrate - highest win rate, with small samples pulled toward the average so a
//             3-game 100% item doesn't win (Bayesian shrinkage)
//   popular - what players pick most often (the safe, proven choice)
// Item slots are chosen one at a time: each slot looks only at games that already
// contain the items picked for earlier slots. Locked slots are kept as given.
const stats = require('./stats');
const ddragon = require('./ddragon');

const keystoneOf = (r) => Number(r.r.split('|')[0].split(':')[1].split(',')[0]);
const primaryOf = (r) => r.r.split('|')[0].split(':')[1].split(',').map(Number);
const subOf = (r) => { const [st, ids] = r.r.split('|')[1].split(':'); return { style: Number(st), ids: ids.split(',').map(Number) }; };
const shardsOf = (r) => r.r.split('|')[2].split(',').map(Number);

function metrics(list) {
  const n = list.length;
  if (!n) return { games: 0 };
  let w = 0, k = 0, d = 0, a = 0, dm = 0, cs = 0, g = 0, du = 0;
  for (const r of list) { w += r.w; k += r.k; d += r.d; a += r.a; dm += r.dm; cs += r.cs; g += r.g; du += r.du; }
  const mins = du / 60 || 1;
  return {
    games: n, wins: w, winRate: w / n, kda: (k + a) / Math.max(1, d),
    kills: k / n, deaths: d / n, assists: a / n, dpm: dm / mins, cspm: cs / mins, gpm: g / mins,
  };
}

function ranker(baseline, mode, minGames) {
  const prior = 15;
  return (m) => {
    if (m.games < minGames) return -Infinity;
    if (mode === 'popular') return m.games;
    return (m.wins + prior * baseline) / (m.games + prior);
  };
}

function groupBy(list, keyFn) {
  const out = new Map();
  for (const r of list) {
    const keys = [].concat(keyFn(r));
    for (const k of keys) { if (k == null) continue; if (!out.has(k)) out.set(k, []); out.get(k).push(r); }
  }
  return out;
}

const rank = (groups, score, total) => [...groups.entries()]
  .map(([key, l]) => { const m = metrics(l); return { key, ...m, share: m.games / total, score: score(m) }; })
  .sort((a, b) => b.score - a.score || b.games - a.games);

function plan(championId, { position, keystone, fixed = [], mode = 'winrate', elo } = {}) {
  const dd = ddragon.get();
  const { list: all, patches } = stats.championRecords(championId, elo);
  const byPos = groupBy(all, (r) => r.p);
  const positions = [...byPos.entries()].map(([p, l]) => ({ position: p, games: l.length })).sort((a, b) => b.games - a.games);
  const pos = position && byPos.has(position) ? position : positions[0]?.position;
  const roleRecs = byPos.get(pos) || [];
  const base = { championId, position: pos || null, positions, patches, mode, totalGames: all.length };
  if (!roleRecs.length) return { ...base, empty: true };

  // ---- keystone comparison (all keystones on this champ + role) ----
  const roleBase = metrics(roleRecs);
  const ksGroups = groupBy(roleRecs, keystoneOf);
  const keystones = [...ksGroups.entries()].map(([id, l]) => ({ id, ...metrics(l), share: l.length / roleRecs.length }))
    .sort((a, b) => b.games - a.games);
  const ks = keystone && ksGroups.has(Number(keystone)) ? Number(keystone) : keystones[0].id;
  const recs = ksGroups.get(ks) || [];
  const baseline = metrics(recs);
  const minGames = Math.max(3, Math.round(recs.length * 0.03));
  const score = ranker(baseline.winRate, mode, minGames);
  const ksInfo = dd.runes[ks] || {};

  // keystone requested but never seen with this champ/role
  if (keystone && !ksGroups.has(Number(keystone))) {
    return { ...base, roleBaseline: roleBase, keystones, keystone: Number(keystone), noKeystoneData: true };
  }

  // ---- primary tree rows ----
  const tree = ksInfo.style;
  const slots = dd.styles[tree]?.slots || [];
  const primaryRows = slots.slice(1).map((ids) => {
    const options = ids.map((id) => {
      const l = recs.filter((r) => primaryOf(r).includes(id));
      const m = metrics(l);
      return { id, ...m, share: m.games / recs.length, score: score(m) };
    });
    const best = [...options].sort((a, b) => b.score - a.score || b.games - a.games)[0];
    return { options, best: best && best.games ? best.id : null };
  });

  // ---- secondary tree + its two runes ----
  const secondaryTrees = rank(groupBy(recs, (r) => subOf(r).style), score, recs.length);
  const subTree = secondaryTrees.find((t) => t.score > -Infinity) || secondaryTrees[0];
  const inTree = recs.filter((r) => subOf(r).style === subTree?.key);
  const subPairs = rank(groupBy(inTree, (r) => [...subOf(r).ids].sort((a, b) => a - b).join(',')), ranker(baseline.winRate, mode, Math.max(2, Math.round(inTree.length * 0.04))), inTree.length);
  const subRunes = rank(groupBy(inTree, (r) => subOf(r).ids), score, inTree.length);

  // ---- stat shards (offense / flex / defense) ----
  const shardRows = [0, 1, 2].map((i) => rank(groupBy(recs, (r) => shardsOf(r)[i]), score, recs.length).slice(0, 4));

  // ---- most-played complete page, for reference ----
  const popularPage = rank(groupBy(recs, (r) => r.r), (m) => m.games, recs.length)[0];

  // ---- item path ----
  const chosen = []; const itemSlots = [];
  for (let slot = 0; slot < 5; slot++) {
    const pool = recs.filter((r) => chosen.every((id, i) => (i === 0 ? r.i[0] === id : r.i.includes(id))));
    const cands = rank(groupBy(pool, (r) => (slot === 0 ? r.i[0] : r.i.filter((id) => !chosen.includes(id)))), score, pool.length || 1);
    const lockId = Number(fixed[slot]) || null;
    let pick;
    if (lockId) {
      const l = pool.filter((r) => (slot === 0 ? r.i[0] === lockId : r.i.includes(lockId)));
      pick = { key: lockId, ...metrics(l), share: pool.length ? l.length / pool.length : 0, locked: true };
    } else {
      pick = cands.find((c) => c.score > -Infinity);
      if (!pick) break; // not enough games past this point; later items are situational
    }
    chosen.push(Number(pick.key));
    itemSlots.push({
      item: Number(pick.key), locked: !!pick.locked, games: pick.games, winRate: pick.winRate, share: pick.share, poolGames: pool.length,
      alts: cands.filter((c) => Number(c.key) !== Number(pick.key) && c.games >= 2).slice(0, 4)
        .map((c) => ({ item: Number(c.key), games: c.games, winRate: c.winRate, share: c.share })),
    });
  }
  const boots = rank(groupBy(recs.filter((r) => r.b), (r) => r.b), score, recs.length).slice(0, 4)
    .map((b) => ({ item: Number(b.key), games: b.games, winRate: b.winRate, share: b.share }));
  const spells = rank(groupBy(recs, (r) => r.s), score, recs.length).slice(0, 3)
    .map((s) => ({ key: s.key, games: s.games, winRate: s.winRate, share: s.share }));

  // ---- totals for the finished build ----
  const buildItems = [...chosen, ...(boots[0] ? [boots[0].item] : [])];
  const totals = {}; let gold = 0;
  for (const id of buildItems) {
    const it = dd.items[id]; if (!it) continue;
    gold += it.gold;
    for (const [v, pct, name] of it.stats || []) {
      const key = name + (pct ? ' %' : '');
      totals[key] = (totals[key] || 0) + v;
    }
  }

  return {
    ...base, roleBaseline: roleBase, baseline, keystone: ks, tree, keystones, minGames,
    runes: {
      primaryRows, secondaryTrees: secondaryTrees.slice(0, 5).map(({ key, games, winRate, share, kda, dpm }) => ({ style: key, games, winRate, share, kda, dpm })),
      subTree: subTree?.key, subPair: subPairs.find((p) => p.score > -Infinity)?.key || subPairs[0]?.key, subRunes: subRunes.slice(0, 6),
      shards: shardRows.map((row) => row.map(({ key, games, winRate, share }) => ({ id: key, games, winRate, share }))),
      popularPage: popularPage && { key: popularPage.key, games: popularPage.games, winRate: popularPage.winRate },
    },
    items: itemSlots, boots, spells,
    totals: { gold, stats: Object.entries(totals).map(([name, value]) => ({ name, value: Math.round(value * 10) / 10 })) },
  };
}

// Every build played on a champion, ranked. A build is the set of the first three completed
// items (any order); each row shows the order and rune page players used most with it.
function rankings(championId, { position, elo, sort = 'winrate', size = 3 } = {}) {
  const { list: all, patches } = stats.championRecords(championId, elo);
  const byPos = groupBy(all, (r) => r.p);
  const positions = [...byPos.entries()].map(([p, l]) => ({ position: p, games: l.length })).sort((a, b) => b.games - a.games);
  const pos = position && byPos.has(position) ? position : positions[0]?.position;
  const recs = (byPos.get(pos) || []).filter((r) => r.i.length >= Math.min(size, 2));
  const base = metrics(byPos.get(pos) || []);
  const groups = groupBy(recs, (r) => [...r.i.slice(0, size)].sort((a, b) => a - b).join('-'));
  const minGames = Math.max(3, Math.round(recs.length * 0.005));
  const mostCommon = (list, fn) => { const c = new Map(); for (const r of list) { const k = fn(r); c.set(k, (c.get(k) || 0) + 1); } return [...c.entries()].sort((a, b) => b[1] - a[1])[0]?.[0]; };
  const rows = [...groups.entries()].filter(([, l]) => l.length >= minGames).map(([key, l]) => {
    const m = metrics(l);
    const order = mostCommon(l, (r) => r.i.slice(0, size).join('-'));
    return {
      items: order.split('-').map(Number), boots: mostCommon(l.filter((r) => r.b), (r) => r.b) || 0,
      runes: mostCommon(l, (r) => r.r), spells: mostCommon(l, (r) => r.s),
      games: m.games, winRate: m.winRate, kda: m.kda, kills: m.kills, deaths: m.deaths, assists: m.assists, dpm: m.dpm,
      share: m.games / recs.length,
    };
  });
  const keyFn = { winrate: (r) => r.winRate, kda: (r) => r.kda, games: (r) => r.games, damage: (r) => r.dpm }[sort] || ((r) => r.winRate);
  rows.sort((a, b) => keyFn(b) - keyFn(a) || b.games - a.games);
  return { championId, position: pos || null, positions, patches, games: recs.length, baseline: base, minGames, sort, rows: rows.slice(0, 40) };
}

module.exports = { plan, rankings };
