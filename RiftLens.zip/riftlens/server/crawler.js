// Background collector: samples ranked solo games from players of every rank in your
// region (Iron to Challenger, taking turns between rank brackets) and feeds them into stats.js. It runs at "low" priority, so it
// pauses whenever you search for something.
const fs = require('fs');
const path = require('path');
const config = require('./config');
const { api, state: riotState } = require('./riot');
const stats = require('./stats');

const SEEN_FILE = path.join(config.DATA_DIR, 'seen.json');
let seen = new Set();
try { seen = new Set(JSON.parse(fs.readFileSync(SEEN_FILE, 'utf8'))); } catch {}

const BRACKETS = Object.keys(stats.BRACKETS);
const DIVISIONS = ['I', 'II', 'III', 'IV'];
const state = {
  running: false, status: 'idle', processed: 0, pools: {}, turn: 0, perBracket: {},
  seededFor: null, lastError: null,
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function saveSeen() {
  const arr = [...seen];
  fs.writeFileSync(SEEN_FILE, JSON.stringify(arr.slice(-150000)));
}

const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const pickOne = (a) => a[Math.floor(Math.random() * a.length)];

// Find a fresh batch of players for one rank bracket. Apex tiers come from the
// Master/Grandmaster/Challenger leagues; the rest from a random division page of league-v4.
async function seed(platform, bracket) {
  state.status = `finding ${stats.BRACKETS[bracket].label} players`;
  const players = [];
  if (bracket === 'apex') {
    for (const tier of ['challenger', 'grandmaster', 'master']) {
      const league = await api.apexLeague(platform, tier, 'low');
      for (const e of league.entries || []) if (e.puuid) players.push(e.puuid);
    }
  } else {
    for (const tier of shuffle([...stats.BRACKETS[bracket].tiers]).slice(0, 2)) {
      const page = 1 + Math.floor(Math.random() * 3);
      const entries = await api.leagueEntries(platform, tier, pickOne(DIVISIONS), page, 'low');
      for (const e of entries || []) if (e.puuid) players.push(e.puuid);
    }
  }
  state.pools[bracket] = { players: shuffle([...new Set(players)]).slice(0, 300), idx: 0, at: Date.now() };
}

async function loop() {
  if (state.running) return;
  state.running = true;
  while (true) {
    const cfg = config.get();
    if (!cfg.crawler) { state.status = 'paused in Settings'; await sleep(3000); continue; }
    if (!cfg.apiKey) { state.status = 'waiting for an API key'; await sleep(3000); continue; }
    if (riotState.keyProblem) { state.status = 'API key expired'; await sleep(5000); continue; }
    try {
      if (state.seededFor !== cfg.platform) { state.pools = {}; state.seededFor = cfg.platform; }
      const bracket = BRACKETS[state.turn++ % BRACKETS.length]; // take turns so every rank gets games
      let pool = state.pools[bracket];
      if (!pool || pool.idx >= pool.players.length || Date.now() - pool.at > 6 * 3600e3) {
        await seed(cfg.platform, bracket);
        pool = state.pools[bracket];
        if (!pool.players.length) { await sleep(5000); continue; }
      }
      const puuid = pool.players[pool.idx++];
      state.status = 'collecting games';
      const ids = await api.matchIds(cfg.platform, puuid, { queue: 420, type: 'ranked', count: 5 }, 'low');
      for (const id of ids) {
        if (seen.has(id) || config.get().platform !== cfg.platform) continue;
        const m = await api.match(cfg.platform, id, 'low');
        seen.add(id);
        if (stats.addMatch(m, bracket)) { state.processed++; state.perBracket[bracket] = (state.perBracket[bracket] || 0) + 1; }
        if (state.processed % 25 === 0) { saveSeen(); stats.save(); }
      }
      state.lastError = null;
    } catch (e) {
      state.lastError = e.message;
      state.status = 'retrying after an error';
      await sleep(15000);
    }
  }
}

function start() { loop(); }
function clear() { seen = new Set(); saveSeen(); stats.reset(); state.processed = 0; }
process.on('exit', () => { try { saveSeen(); stats.save(); } catch {} });

module.exports = { start, state, clear };
