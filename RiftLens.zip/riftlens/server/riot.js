// Riot API client with a rate limiter that respects the personal key limits
// (20 req/s and 100 req/2 min by default, read live from Riot's response headers).
// Your own lookups ("high" priority) always jump ahead of the background crawler ("low").
const config = require('./config');

const REGIONS = {
  euw1: { label: 'EUW', regional: 'europe', account: 'europe' },
  eun1: { label: 'EUNE', regional: 'europe', account: 'europe' },
  tr1: { label: 'TR', regional: 'europe', account: 'europe' },
  ru: { label: 'RU', regional: 'europe', account: 'europe' },
  me1: { label: 'ME', regional: 'europe', account: 'europe' },
  na1: { label: 'NA', regional: 'americas', account: 'americas' },
  br1: { label: 'BR', regional: 'americas', account: 'americas' },
  la1: { label: 'LAN', regional: 'americas', account: 'americas' },
  la2: { label: 'LAS', regional: 'americas', account: 'americas' },
  kr: { label: 'KR', regional: 'asia', account: 'asia' },
  jp1: { label: 'JP', regional: 'asia', account: 'asia' },
  oc1: { label: 'OCE', regional: 'sea', account: 'asia' },
  sg2: { label: 'SG', regional: 'sea', account: 'asia' },
  tw2: { label: 'TW', regional: 'sea', account: 'asia' },
  vn2: { label: 'VN', regional: 'sea', account: 'asia' },
};

class RiotError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- rate limiter (one per routing host, since Riot counts limits per region) ----
class Limiter {
  constructor() {
    this.limits = [[20, 1000], [100, 120000]];
    this.stamps = [];
    this.queue = [];
    this.blockedUntil = 0;
    this.timer = null;
  }
  setLimits(header) {
    // e.g. "20:1,100:120"
    const parsed = String(header).split(',').map((s) => s.split(':').map(Number))
      .filter(([n, s]) => n > 0 && s > 0).map(([n, s]) => [n, s * 1000]);
    if (parsed.length) this.limits = parsed;
  }
  schedule(fn, priority = 'high') {
    return new Promise((resolve, reject) => {
      const job = { fn, priority, resolve, reject };
      if (priority === 'high') {
        const i = this.queue.findIndex((j) => j.priority === 'low');
        i === -1 ? this.queue.push(job) : this.queue.splice(i, 0, job);
      } else this.queue.push(job);
      this.pump();
    });
  }
  waitFor(priority) {
    const now = Date.now();
    if (now < this.blockedUntil) return this.blockedUntil - now;
    const longest = Math.max(...this.limits.map((l) => l[1]));
    this.stamps = this.stamps.filter((t) => now - t < longest);
    let wait = 0;
    for (const [n, ms] of this.limits) {
      const inWindow = this.stamps.filter((t) => now - t < ms);
      // keep ~35% of each window free for your own searches
      const cap = priority === 'low' ? Math.max(1, Math.floor(n * 0.65)) : n;
      if (inWindow.length >= cap) wait = Math.max(wait, ms - (now - inWindow[inWindow.length - cap]) + 5);
    }
    return wait;
  }
  pump() {
    if (this.timer || !this.queue.length) return;
    const job = this.queue[0];
    const wait = this.waitFor(job.priority);
    if (wait > 0) {
      this.timer = setTimeout(() => { this.timer = null; this.pump(); }, Math.min(wait, 2000));
      return;
    }
    this.queue.shift();
    this.stamps.push(Date.now());
    job.fn().then(job.resolve, job.reject);
    setImmediate(() => this.pump());
  }
  pending(priority) { return this.queue.filter((j) => !priority || j.priority === priority).length; }
}

const limiters = {};
const limiterFor = (host) => (limiters[host] ||= new Limiter());

const state = { keyProblem: null, lastOk: 0 };

function baseUrl(host) {
  const override = process.env.RIOT_BASE_OVERRIDE; // used by the test harness only
  return override ? `${override}/${host}` : `https://${host}.api.riotgames.com`;
}

async function get(host, path, { query, priority = 'high', retries = 3 } = {}) {
  const key = config.get().apiKey;
  if (!key) throw new RiotError(401, 'No Riot API key set. Add one in Settings.');
  const qs = query ? '?' + new URLSearchParams(query).toString() : '';
  const url = baseUrl(host) + path + qs;
  const limiter = limiterFor(host);

  const res = await limiter.schedule(() => fetch(url, { headers: { 'X-Riot-Token': key } }), priority);
  const appLimit = res.headers.get('x-app-rate-limit');
  if (appLimit) limiter.setLimits(appLimit);

  if (res.status === 429) {
    const retryAfter = Number(res.headers.get('retry-after') || 5);
    limiter.blockedUntil = Date.now() + retryAfter * 1000;
    if (retries > 0) {
      await sleep(retryAfter * 1000);
      return get(host, path, { query, priority, retries: retries - 1 });
    }
    throw new RiotError(429, 'Rate limited by Riot. Try again in a moment.');
  }
  if (res.status === 401 || res.status === 403) {
    state.keyProblem = 'Your Riot API key was rejected. Personal keys expire every 24 hours, so paste a fresh one in Settings.';
    throw new RiotError(res.status, state.keyProblem);
  }
  if (res.status >= 500 && retries > 0) {
    await sleep(1500);
    return get(host, path, { query, priority, retries: retries - 1 });
  }
  if (!res.ok) {
    let msg = `Riot API error ${res.status}`;
    try { const body = await res.json(); if (body?.status?.message) msg += `: ${body.status.message}`; } catch {}
    throw new RiotError(res.status, msg);
  }
  state.keyProblem = null;
  state.lastOk = Date.now();
  return res.json();
}

function region(platform = config.get().platform) {
  const r = REGIONS[platform];
  if (!r) throw new RiotError(400, `Unknown region "${platform}"`);
  return { platform, ...r };
}

// ---- endpoint helpers ----
const enc = encodeURIComponent;
const api = {
  account: (p, name, tag, pr) => get(region(p).account, `/riot/account/v1/accounts/by-riot-id/${enc(name)}/${enc(tag)}`, { priority: pr }),
  summoner: (p, puuid, pr) => get(p, `/lol/summoner/v4/summoners/by-puuid/${puuid}`, { priority: pr }),
  ranks: (p, puuid, pr) => get(p, `/lol/league/v4/entries/by-puuid/${puuid}`, { priority: pr }),
  topMastery: (p, puuid, count = 6) => get(p, `/lol/champion-mastery/v4/champion-masteries/by-puuid/${puuid}/top`, { query: { count } }),
  masteryOn: async (p, puuid, champId) => {
    try { return await get(p, `/lol/champion-mastery/v4/champion-masteries/by-puuid/${puuid}/by-champion/${champId}`); }
    catch (e) { if (e.status === 404) return null; throw e; }
  },
  matchIds: (p, puuid, query, pr) => get(region(p).regional, `/lol/match/v5/matches/by-puuid/${puuid}/ids`, { query, priority: pr }),
  match: (p, id, pr) => get(region(p).regional, `/lol/match/v5/matches/${id}`, { priority: pr }),
  activeGame: async (p, puuid) => {
    try { return await get(p, `/lol/spectator/v5/active-games/by-summoner/${puuid}`); }
    catch (e) { if (e.status === 404) return null; throw e; }
  },
  leagueEntries: (p, tier, division, page, pr) => get(p, `/lol/league/v4/entries/RANKED_SOLO_5x5/${tier}/${division}`, { query: { page }, priority: pr }),
  apexLeague: (p, tier, pr) => get(p, `/lol/league/v4/${tier}leagues/by-queue/RANKED_SOLO_5x5`, { priority: pr }),
  status: (p) => get(p, '/lol/status/v4/platform-data'),
};

module.exports = { api, REGIONS, RiotError, state, limiterFor, region };
