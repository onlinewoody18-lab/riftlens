// Matchup score: how well you match up against one enemy player, 0-100 (50 = even).
// Four factors, each turned into an "edge" between -1 (they're far ahead) and +1 (you are):
//   champion matchup  - ranked win rate of your champ vs theirs in that lane
//   rank              - your solo queue rank vs theirs
//   champion experience - your mastery on your pick vs theirs on their pick
//   recent form       - your season win rate vs theirs
// Missing factors (e.g. unranked, no matchup data yet) are left out and the rest re-weighted.
const stats = require('./stats');
const ddragon = require('./ddragon');

const TIERS = ['IRON', 'BRONZE', 'SILVER', 'GOLD', 'PLATINUM', 'EMERALD', 'DIAMOND', 'MASTER', 'GRANDMASTER', 'CHALLENGER'];
const DIVS = { IV: 0, III: 1, II: 2, I: 3 };
const clamp = (x) => Math.max(-1, Math.min(1, x));

function soloRank(entries) {
  if (!entries) return null;
  return entries.find((e) => e.queueType === 'RANKED_SOLO_5x5') || entries.find((e) => e.queueType === 'RANKED_FLEX_SR') || null;
}

function rankPoints(r) {
  if (!r) return null;
  const t = TIERS.indexOf(r.tier);
  if (t < 0) return null;
  if (t >= 7) return 2800 + (r.leaguePoints || 0); // apex tiers share one LP ladder
  return t * 400 + (DIVS[r.rank] ?? 0) * 100 + (r.leaguePoints || 0);
}

const rankLabel = (r) => (r ? `${r.tier[0]}${r.tier.slice(1).toLowerCase()}${TIERS.indexOf(r.tier) >= 7 ? '' : ' ' + r.rank} ${r.leaguePoints} LP` : 'Unranked');
const fmtPts = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? Math.round(n / 1e3) + 'k' : String(n || 0));

function score(me, them, lanePosition) {
  const factors = [];
  const cName = (id) => ddragon.champByKey(id)?.name || 'Unknown';

  // 1. champion matchup
  const mu = stats.matchup(me.championId, them.championId, lanePosition || undefined);
  if (mu.games >= 3) {
    const wr = (mu.wins + 10) / (mu.games + 20);
    factors.push({
      key: 'matchup', label: 'Champion matchup', weight: mu.games >= 15 ? 0.3 : 0.15,
      edge: clamp((wr - 0.5) * 10),
      detail: `${cName(me.championId)} wins ${(100 * mu.wins / mu.games).toFixed(0)}% vs ${cName(them.championId)} (${mu.games} ranked games)`,
    });
  }

  // 2. rank
  const myR = soloRank(me.ranks); const theirR = soloRank(them.ranks);
  const a = rankPoints(myR); const b = rankPoints(theirR);
  if (a !== null && b !== null) {
    factors.push({ key: 'rank', label: 'Rank', weight: 0.3, edge: clamp((a - b) / 600), detail: `${rankLabel(myR)} vs ${rankLabel(theirR)}` });
  }

  // 3. champion experience
  const mp = me.mastery?.championPoints || 0; const tp = them.mastery?.championPoints || 0;
  factors.push({
    key: 'mastery', label: 'Champion experience', weight: 0.2,
    edge: clamp((Math.log10(mp + 1000) - Math.log10(tp + 1000)) / 1.5),
    detail: `${fmtPts(mp)} mastery on ${cName(me.championId)} vs ${fmtPts(tp)} on ${cName(them.championId)}`,
  });

  // 4. recent form
  if (myR && theirR) {
    const wr = (r) => (r.wins + 10) / (r.wins + r.losses + 20);
    const pct = (r) => Math.round(100 * r.wins / Math.max(1, r.wins + r.losses));
    factors.push({ key: 'form', label: 'Season form', weight: 0.2, edge: clamp((wr(myR) - wr(theirR)) * 6), detail: `${pct(myR)}% win rate vs ${pct(theirR)}%` });
  }

  const wSum = factors.reduce((n, f) => n + f.weight, 0);
  const total = factors.reduce((n, f) => n + f.weight * f.edge, 0) / (wSum || 1);
  const value = Math.round(50 + 50 * total);
  const verdict = value >= 65 ? 'Favourable matchup' : value >= 55 ? 'Slight edge' : value > 45 ? 'Even matchup' : value > 35 ? 'Slight disadvantage' : 'Uphill matchup';
  return { score: value, verdict, factors: factors.map((f) => ({ ...f, edge: Math.round(f.edge * 100) / 100 })) };
}

// ---- guess each player's role in a live game (spectator data has no positions) ----
const TAG_PRIOR = {
  Marksman: { BOTTOM: 6, MIDDLE: 1, TOP: 0.5 },
  Support: { UTILITY: 6, MIDDLE: 0.5 },
  Mage: { MIDDLE: 4, UTILITY: 2, BOTTOM: 0.5 },
  Assassin: { MIDDLE: 3, JUNGLE: 2 },
  Fighter: { TOP: 4, JUNGLE: 2 },
  Tank: { TOP: 2, UTILITY: 2, JUNGLE: 2 },
};
const SMITE = 11;

function rolePrefs(p) {
  const counts = stats.positionCounts(p.championId);
  const tags = ddragon.champByKey(p.championId)?.tags || [];
  const prefs = {};
  for (const pos of stats.POSITIONS) {
    let prior = 0.2;
    for (const t of tags) prior += TAG_PRIOR[t]?.[pos] || 0;
    prefs[pos] = (counts[pos] || 0) + prior;
  }
  const hasSmite = p.spell1Id === SMITE || p.spell2Id === SMITE;
  for (const pos of stats.POSITIONS) prefs[pos] *= hasSmite ? (pos === 'JUNGLE' ? 50 : 0.02) : (pos === 'JUNGLE' ? 0.05 : 1);
  const sum = Object.values(prefs).reduce((a, b) => a + b, 0);
  for (const pos of stats.POSITIONS) prefs[pos] /= sum;
  return prefs;
}

function permutations(arr) {
  if (arr.length <= 1) return [arr];
  return arr.flatMap((x, i) => permutations([...arr.slice(0, i), ...arr.slice(i + 1)]).map((p) => [x, ...p]));
}

function assignRoles(team) {
  const prefs = team.map(rolePrefs);
  if (team.length !== 5) return team.map(() => null);
  let best = null; let bestScore = -Infinity;
  for (const perm of permutations(stats.POSITIONS)) {
    const s = perm.reduce((n, pos, i) => n + Math.log(prefs[i][pos] + 1e-9), 0);
    if (s > bestScore) { bestScore = s; best = perm; }
  }
  return best;
}

module.exports = { score, assignRoles, soloRank, rankLabel, rankPoints, TIERS };
