// RiftLens server. Serves the web app and talks to Riot on the visitor's behalf, so the
// API key never reaches the browser.
// - On your PC (default): listens on 127.0.0.1 only, settings editable in the app.
// - Online (RIFTLENS_HOSTED=1): listens on all interfaces, key and region come from
//   environment variables, settings are locked, lookups are rate-limited per visitor,
//   and each visitor's Riot ID and saved builds stay in their own browser.
const http = require('http');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const ddragon = require('./ddragon');
const stats = require('./stats');
const crawler = require('./crawler');
const scoring = require('./scoring');
const planner = require('./planner');
const builds = require('./builds');
const { api, REGIONS, RiotError, state: riotState, limiterFor, region } = require('./riot');

const PORT = Number(process.env.PORT || 3170);
const HOSTED = config.HOSTED;
const BIND = process.env.HOST || (HOSTED ? '0.0.0.0' : '127.0.0.1');
// Hostnames the server answers to. Locally only this PC; online, your domain(s).
const ALLOWED_HOSTS = HOSTED
  ? (process.env.PUBLIC_HOSTS || '').split(',').map((h) => h.trim().toLowerCase()).filter(Boolean)
  : ['localhost', '127.0.0.1'];
const PUBLIC = path.join(__dirname, '..', 'public');
const MATCH_DIR = path.join(config.DATA_DIR, 'matches');
fs.mkdirSync(MATCH_DIR, { recursive: true });

// ---- small caches ----
const memo = new Map();
async function cached(key, ttlMs, fn) {
  const hit = memo.get(key);
  if (hit && Date.now() - hit.t < ttlMs) return hit.v;
  const v = await fn();
  memo.set(key, { t: Date.now(), v });
  if (memo.size > 500) memo.delete(memo.keys().next().value);
  return v;
}

async function getMatch(platform, id) {
  if (HOSTED) return cached('match:' + id, 3600e3, () => api.match(platform, id, 'high')); // don't fill the server's disk
  const file = path.join(MATCH_DIR, id.replace(/[^\w-]/g, '') + '.json');
  if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  const m = await api.match(platform, id, 'high');
  fs.writeFileSync(file, JSON.stringify(m));
  return m;
}

const QUEUES = {
  420: 'Ranked Solo', 440: 'Ranked Flex', 400: 'Normal Draft', 430: 'Normal Blind', 490: 'Quickplay',
  450: 'ARAM', 1700: 'Arena', 1710: 'Arena', 900: 'ARURF', 1900: 'URF', 1300: 'Nexus Blitz', 700: 'Clash', 720: 'ARAM Clash',
  0: 'Custom', 830: 'Co-op vs AI', 840: 'Co-op vs AI', 850: 'Co-op vs AI', 870: 'Co-op vs AI', 880: 'Co-op vs AI', 890: 'Co-op vs AI',
};

function parseRiotId(raw) {
  const s = decodeURIComponent(raw || '').trim();
  const i = s.lastIndexOf('#') >= 0 ? s.lastIndexOf('#') : s.lastIndexOf('-');
  if (i <= 0) throw new RiotError(400, 'Enter a Riot ID like Name#TAG (the tag is shown under your name in the League client).');
  return { name: s.slice(0, i).trim(), tag: s.slice(i + 1).trim() };
}

// ---- player profile + match history ----
function summarise(m, puuid) {
  const info = m.info;
  const me = info.participants.find((p) => p.puuid === puuid);
  if (!me) return null;
  const teamKills = info.participants.filter((p) => p.teamId === me.teamId).reduce((n, p) => n + p.kills, 0);
  const cs = (me.totalMinionsKilled || 0) + (me.neutralMinionsKilled || 0);
  const mins = info.gameDuration / 60;
  return {
    id: m.metadata.matchId, queueId: info.queueId, queue: QUEUES[info.queueId] || 'Other',
    endedAt: info.gameEndTimestamp || info.gameCreation, duration: info.gameDuration,
    remake: info.gameDuration < 300 || me.gameEndedInEarlySurrender,
    win: me.win, championId: me.championId, position: me.teamPosition, level: me.champLevel,
    kills: me.kills, deaths: me.deaths, assists: me.assists, cs, csPerMin: cs / mins,
    damage: me.totalDamageDealtToChampions, vision: me.visionScore, gold: me.goldEarned,
    kp: teamKills ? (me.kills + me.assists) / teamKills : 0,
    items: [me.item0, me.item1, me.item2, me.item3, me.item4, me.item5, me.item6],
    spells: [me.summoner1Id, me.summoner2Id],
    keystone: me.perks?.styles?.[0]?.selections?.[0]?.perk, subStyle: me.perks?.styles?.[1]?.style,
    multikill: me.pentaKills ? 'Penta kill' : me.quadraKills ? 'Quadra kill' : me.tripleKills ? 'Triple kill' : null,
    players: info.participants.map((p) => ({
      teamId: p.teamId, championId: p.championId, name: p.riotIdGameName || p.summonerName || '?', tag: p.riotIdTagline || '',
      kills: p.kills, deaths: p.deaths, assists: p.assists, isMe: p.puuid === puuid,
    })),
  };
}

async function playerProfile(platform, riotId, count = 15) {
  const { name, tag } = parseRiotId(riotId);
  return cached(`p:${platform}:${name.toLowerCase()}#${tag.toLowerCase()}:${count}`, 90e3, async () => {
    const acct = await api.account(platform, name, tag);
    const [summ, ranks, mastery, ids] = await Promise.all([
      api.summoner(platform, acct.puuid), api.ranks(platform, acct.puuid),
      api.topMastery(platform, acct.puuid, 6), api.matchIds(platform, acct.puuid, { count }),
    ]);
    const matches = (await Promise.all(ids.map((id) => getMatch(platform, id).catch(() => null))))
      .filter(Boolean).map((m) => summarise(m, acct.puuid)).filter(Boolean)
      .sort((a, b) => b.endedAt - a.endedAt);

    const real = matches.filter((m) => !m.remake);
    const agg = { games: real.length, wins: real.filter((m) => m.win).length, kills: 0, deaths: 0, assists: 0, csPerMin: 0, kp: 0 };
    const champs = {}; const roles = {};
    for (const m of real) {
      agg.kills += m.kills; agg.deaths += m.deaths; agg.assists += m.assists; agg.csPerMin += m.csPerMin; agg.kp += m.kp;
      const c = (champs[m.championId] ||= { championId: m.championId, games: 0, wins: 0, k: 0, d: 0, a: 0 });
      c.games++; if (m.win) c.wins++; c.k += m.kills; c.d += m.deaths; c.a += m.assists;
      if (m.position) { const r = (roles[m.position] ||= { position: m.position, games: 0, wins: 0 }); r.games++; if (m.win) r.wins++; }
    }
    if (agg.games) { agg.csPerMin /= agg.games; agg.kp /= agg.games; }

    return {
      riotId: `${acct.gameName}#${acct.tagLine}`, puuid: acct.puuid, platform, regionLabel: REGIONS[platform].label,
      level: summ.summonerLevel, icon: summ.profileIconId, ranks,
      mastery: mastery.map((x) => ({ championId: x.championId, level: x.championLevel, points: x.championPoints })),
      recent: agg,
      champions: Object.values(champs).sort((a, b) => b.games - a.games),
      roles: Object.values(roles).sort((a, b) => b.games - a.games),
      matches,
    };
  });
}

// ---- live game with matchup scores ----
async function liveGame(platform, riotId) {
  const { name, tag } = parseRiotId(riotId);
  return cached(`l:${platform}:${name.toLowerCase()}#${tag.toLowerCase()}`, 45e3, async () => {
    const acct = await api.account(platform, name, tag);
    const game = await api.activeGame(platform, acct.puuid);
    if (!game) return { inGame: false, riotId: `${acct.gameName}#${acct.tagLine}` };

    const players = await Promise.all(game.participants.map(async (p) => {
      if (p.bot || !p.puuid) return { ...p, ranks: [], mastery: null };
      const [ranks, mastery] = await Promise.all([
        api.ranks(platform, p.puuid, 'high').catch(() => []),
        api.masteryOn(platform, p.puuid, p.championId).catch(() => null),
      ]);
      return { ...p, ranks, mastery };
    }));

    for (const teamId of [100, 200]) {
      const team = players.filter((p) => p.teamId === teamId);
      const roles = scoring.assignRoles(team);
      team.forEach((p, i) => { p.role = roles[i]; });
    }

    const me = players.find((p) => p.puuid === acct.puuid);
    const enemies = players.filter((p) => p.teamId !== me.teamId);
    const matchups = enemies.map((e) => ({
      puuid: e.puuid, laneOpponent: !!me.role && e.role === me.role,
      ...scoring.score(me, e, me.role && e.role === me.role ? me.role : null),
    }));
    const lane = matchups.find((m) => m.laneOpponent);
    const avgRank = (team) => {
      const pts = team.map((p) => scoring.rankPoints(scoring.soloRank(p.ranks))).filter((x) => x !== null);
      return pts.length ? Math.round(pts.reduce((a, b) => a + b, 0) / pts.length) : null;
    };

    return {
      inGame: true, riotId: `${acct.gameName}#${acct.tagLine}`, myPuuid: acct.puuid, myTeam: me.teamId,
      gameMode: game.gameMode, queue: QUEUES[game.gameQueueConfigId] || game.gameMode,
      startedAt: game.gameStartTime, gameLength: game.gameLength,
      bans: game.bannedChampions || [],
      players: players.map((p) => ({
        puuid: p.puuid, teamId: p.teamId, championId: p.championId, role: p.role,
        riotId: p.riotId || p.summonerName || 'Bot', spells: [p.spell1Id, p.spell2Id],
        keystone: p.perks?.perkIds?.[0], subStyle: p.perks?.perkSubStyle,
        rank: scoring.soloRank(p.ranks), rankLabel: scoring.rankLabel(scoring.soloRank(p.ranks)),
        masteryPoints: p.mastery?.championPoints || 0, masteryLevel: p.mastery?.championLevel || 0,
      })),
      matchups, laneScore: lane?.score ?? null,
      teamAvgRank: { [me.teamId]: avgRank(players.filter((p) => p.teamId === me.teamId)), enemy: avgRank(enemies) },
    };
  });
}

// ---- status / settings ----
function status() {
  const cfg = config.get();
  return {
    hosted: HOSTED,
    hasKey: !!cfg.apiKey, keyHint: cfg.apiKey && !HOSTED ? '••••' + cfg.apiKey.slice(-4) : null,
    keyProblem: riotState.keyProblem && (HOSTED ? 'Riot data is unavailable right now. Please try again later.' : riotState.keyProblem), platform: cfg.platform, riotId: cfg.riotId, crawlerEnabled: cfg.crawler,
    regions: Object.fromEntries(Object.entries(REGIONS).map(([k, v]) => [k, v.label])),
    crawler: { status: crawler.state.status, processed: crawler.state.processed, perBracket: crawler.state.perBracket, lastError: crawler.state.lastError },
    brackets: Object.fromEntries(Object.entries(stats.BRACKETS).map(([k, v]) => [k, v.label])),
    data: stats.summary(),
    queue: { mine: limiterFor(cfg.platform).pending('high') + limiterFor(region().regional).pending('high') },
  };
}

async function saveSettings(body) {
  const before = { ...config.get() };
  if (body.platform && !REGIONS[body.platform]) throw new RiotError(400, 'Unknown region');
  const oldKey = before.apiKey; const oldProblem = riotState.keyProblem;
  config.update(body);
  if (body.apiKey !== undefined) {
    riotState.keyProblem = null;
    memo.clear();
    if (body.apiKey) {
      try { await api.status(config.get().platform); }
      catch (e) {
        config.update({ apiKey: oldKey }); // keep the previous key if the new one fails
        riotState.keyProblem = oldProblem;
        throw new RiotError(e.status || 400, e.status === 401 || e.status === 403 ? 'Riot rejected that key. Copy it again from developer.riotgames.com (it starts with RGAPI-).' : e.message);
      }
    }
  }
  if (body.platform && body.platform !== before.platform) memo.clear();
  return status();
}

// ---- http plumbing ----
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };

function send(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (c) => { raw += c; if (raw.length > 1e5) req.destroy(); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new RiotError(400, 'Bad JSON')); } });
  });
}

const routes = [
  ['GET', /^\/api\/status$/, () => status()],
  ['POST', /^\/api\/settings$/, async (m, req) => saveSettings(await readBody(req))],
  ['GET', /^\/api\/static$/, async () => {
    const d = await ddragon.load();
    return { version: d.version, champions: d.champions, items: d.items, spells: d.spells, runes: d.runes, styles: d.styles, cdn: ddragon.BASE };
  }],
  ['GET', /^\/api\/player\/([a-z0-9]+)\/(.+)$/, (m) => playerProfile(m[1], m[2])],
  ['GET', /^\/api\/live\/([a-z0-9]+)\/(.+)$/, (m) => liveGame(m[1], m[2])],
  ['GET', /^\/api\/tierlist$/, (m, req, url) => stats.tierList(url.searchParams.get('position'), url.searchParams.get('elo'))],
  ['GET', /^\/api\/champion\/(\d+)$/, (m, req, url) => stats.champion(Number(m[1]), url.searchParams.get('position'), url.searchParams.get('elo'))],
  ['GET', /^\/api\/planner\/(\d+)$/, (m, req, url) => planner.plan(Number(m[1]), {
    position: url.searchParams.get('position') || undefined,
    keystone: url.searchParams.get('keystone') || undefined,
    fixed: (url.searchParams.get('fixed') || '').split(','),
    mode: url.searchParams.get('mode') === 'popular' ? 'popular' : 'winrate',
    elo: url.searchParams.get('elo') || undefined,
  })],
  ['GET', /^\/api\/rankings\/(\d+)$/, (m, req, url) => planner.rankings(Number(m[1]), {
    position: url.searchParams.get('position') || undefined, elo: url.searchParams.get('elo') || undefined,
    sort: url.searchParams.get('sort') || 'winrate',
  })],
  ['GET', /^\/api\/builds$/, () => builds.list()],
  ['POST', /^\/api\/builds$/, async (m, req) => builds.save(await readBody(req))],
  ['DELETE', /^\/api\/builds\/([0-9a-f-]{36})$/, (m) => builds.remove(m[1])],
  ['POST', /^\/api\/check\/(\d+)$/, async (m, req) => builds.check(Number(m[1]), await readBody(req))],
  ['POST', /^\/api\/stats\/reset$/, () => { crawler.clear(); return status(); }],
];

// Things only the owner of a local copy may do.
const LOCAL_ONLY = [/^\/api\/settings$/, /^\/api\/stats\/reset$/, /^\/api\/builds/];
// Per-visitor limit on lookups that call Riot, so one visitor can't use up the shared key.
const LOOKUP_LIMIT = Number(process.env.LOOKUPS_PER_10MIN || 40);
const lookups = new Map();
function clientIp(req) {
  // Behind a hosting provider's proxy (TRUST_PROXY=1) the visitor's address is the last
  // X-Forwarded-For entry. Without a proxy that header could be faked, so it's ignored.
  const xff = process.env.TRUST_PROXY === '1' && req.headers['x-forwarded-for'];
  return xff ? String(xff).split(',').pop().trim() : req.socket.remoteAddress;
}
function overLimit(req) {
  const ip = clientIp(req); const now = Date.now();
  const list = (lookups.get(ip) || []).filter((t) => now - t < 600e3);
  if (list.length >= LOOKUP_LIMIT) { lookups.set(ip, list); return true; }
  list.push(now); lookups.set(ip, list);
  if (lookups.size > 20000) lookups.clear();
  return false;
}

function securityHeaders(res) {
  const dd = new URL(ddragon.BASE).origin;
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Content-Security-Policy', `default-src 'self'; img-src 'self' data: ${dd}; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'`);
  if (HOSTED) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
}

const server = http.createServer(async (req, res) => {
  securityHeaders(res);
  // Only answer requests addressed to this server's own name, so other websites can't
  // use the key through a visitor's browser (DNS rebinding).
  const host = String(req.headers.host || '').replace(/:\d+$/, '').toLowerCase();
  if (ALLOWED_HOSTS.length && !ALLOWED_HOSTS.includes(host)) { res.writeHead(403); return res.end('Forbidden'); }
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) {
    if (HOSTED && LOCAL_ONLY.some((re) => re.test(url.pathname))) return send(res, 403, { error: 'Not available on the online version.' });
    if (HOSTED && /^\/api\/(player|live)\//.test(url.pathname) && overLimit(req)) {
      return send(res, 429, { error: 'Too many lookups from your connection. Wait a few minutes and try again.' });
    }
    for (const [method, re, handler] of routes) {
      const m = url.pathname.match(re);
      if (m && req.method === method) {
        try {
          await ddragon.load();
          return send(res, 200, await handler(m, req, url));
        } catch (e) {
          const code = e.status === 404 ? 404 : e.status && e.status < 600 ? e.status : 500;
          const msg = e.status === 404 && m[0].includes('/player/') || e.status === 404 && m[0].includes('/live/')
            ? "Couldn't find that Riot ID in this region. Check the spelling, the #tag and the region."
            : e.message;
          return send(res, code, { error: msg });
        }
      }
    }
    return send(res, 404, { error: 'Not found' });
  }
  // static files (single-page app falls back to index.html)
  let file = path.normalize(path.join(PUBLIC, url.pathname === '/' ? 'index.html' : url.pathname));
  if (!file.startsWith(PUBLIC) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(PUBLIC, 'index.html');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});

// Desktop launcher (Start RiftLens.bat sets RIFTLENS_OPEN=1): open RiftLens in its own
// app window using Microsoft Edge, which every Windows 10/11 PC has; otherwise the default browser.
function openWindow() {
  const url = `http://localhost:${PORT}`;
  const { spawn } = require('child_process');
  const edge = [process.env['ProgramFiles(x86)'], process.env.ProgramFiles, process.env.LOCALAPPDATA]
    .filter(Boolean).map((d) => path.join(d, 'Microsoft', 'Edge', 'Application', 'msedge.exe')).find((p) => fs.existsSync(p));
  try {
    if (edge) spawn(edge, [`--app=${url}`, '--window-size=1400,900'], { detached: true, stdio: 'ignore' }).unref();
    else if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore' }).unref();
    else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch { console.log(`  Open ${url} in your browser.`); }
}
const WANT_WINDOW = process.env.RIFTLENS_OPEN === '1' && !HOSTED;
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE' && WANT_WINDOW) { console.log('  RiftLens is already running, opening it.'); openWindow(); setTimeout(() => process.exit(0), 500); return; }
  console.error(e.code === 'EADDRINUSE' ? `  Port ${PORT} is already in use. Is RiftLens already running?` : e.message);
  process.exit(1);
});

process.on('SIGINT', () => process.exit(0));
process.on('SIGTERM', () => process.exit(0));

server.listen(PORT, BIND, async () => {
  if (HOSTED) {
    console.log(`RiftLens (online mode) listening on ${BIND}:${PORT}, region ${config.get().platform}`);
    if (!ALLOWED_HOSTS.length) console.warn('Warning: PUBLIC_HOSTS is not set, so any hostname is accepted. Set it to your domain.');
    if (!config.get().apiKey) console.warn('Warning: RIOT_API_KEY is not set.');
  } else {
    console.log(`\n  RiftLens is running → http://localhost:${PORT}\n  (leave this window open while you use it; Ctrl+C to stop)\n`);
    if (WANT_WINDOW) openWindow();
  }
  try { await ddragon.load(); } catch (e) { console.warn('  ' + e.message); }
  crawler.start();
});
