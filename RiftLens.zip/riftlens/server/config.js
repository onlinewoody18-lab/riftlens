// Loads and saves settings (API key, region, your Riot ID).
// On your PC the key lives only in data/config.json and is never sent to the browser.
// Online (RIFTLENS_HOSTED=1) everything comes from environment variables instead, the
// key is never written to disk, and visitors can't change any setting.
const fs = require('fs');
const path = require('path');

const HOSTED = /^(1|true|yes)$/i.test(process.env.RIFTLENS_HOSTED || '');
// Data normally sits next to the app. If that folder is read-only (for example the app was
// unzipped somewhere only administrators can write), fall back to the user's own app-data folder.
function pickDataDir() {
  if (process.env.DATA_DIR) return path.resolve(process.env.DATA_DIR);
  const candidates = [path.join(__dirname, '..', 'data')];
  const userBase = process.env.LOCALAPPDATA || (process.env.HOME && path.join(process.env.HOME, '.local', 'share'));
  if (userBase) candidates.push(path.join(userBase, 'RiftLens', 'data'));
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      const probe = path.join(dir, '.write-test');
      fs.writeFileSync(probe, 'ok'); fs.unlinkSync(probe);
      if (dir !== candidates[0]) console.log(`  Can't write to ${candidates[0]}, so RiftLens is saving its data in ${dir}`);
      return dir;
    } catch { /* try the next one */ }
  }
  throw new Error(`RiftLens can't save its data. Move the riftlens folder somewhere you can write to, such as your Documents folder.`);
}
const DATA_DIR = pickDataDir();
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');

const defaults = {
  apiKey: '',
  platform: 'euw1',
  riotId: '',          // "Name#TAG" — used for one-click live game lookups
  crawler: true,       // collect ranked games for builds and tier list
};

let config = { ...defaults };
try {
  config = { ...defaults, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
} catch { /* first run */ }

if (HOSTED) config = { ...defaults, riotId: '', crawler: process.env.RIFTLENS_CRAWLER !== '0' };
if (process.env.RIOT_API_KEY) config.apiKey = process.env.RIOT_API_KEY.trim();
if (process.env.RIOT_PLATFORM) config.platform = process.env.RIOT_PLATFORM.trim().toLowerCase();

function save() {
  if (HOSTED) return; // online settings come only from the environment
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

function update(patch) {
  for (const k of Object.keys(defaults)) {
    if (patch[k] !== undefined) config[k] = typeof patch[k] === 'string' ? patch[k].trim() : patch[k];
  }
  save();
  return config;
}

module.exports = { get: () => config, update, DATA_DIR, HOSTED };
