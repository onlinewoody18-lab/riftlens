// Riot's public static data (Data Dragon): champions, items, summoner spells and runes.
// No key needed. Cached on disk so the app still works if the CDN is slow.
const fs = require('fs');
const path = require('path');
const { DATA_DIR } = require('./config');

const BASE = process.env.DDRAGON_BASE || 'https://ddragon.leagueoflegends.com';
const CACHE_DIR = path.join(DATA_DIR, 'ddragon');
fs.mkdirSync(CACHE_DIR, { recursive: true });

let dd = null;
let loadedAt = 0;

// Pulls "45 Attack Damage", "20 Ability Haste", "25% Attack Speed" out of an item description.
function parseStats(desc = '') {
  const block = desc.match(/<stats>([\s\S]*?)<\/stats>/i);
  if (!block) return [];
  return block[1].split(/<br\s*\/?>/i).map((line) => line.replace(/<[^>]+>/g, '').trim())
    .map((line) => line.match(/^([\d.]+)(%?)\s+(.+)$/)).filter(Boolean)
    .map(([, v, pctSign, name]) => [Number(v), pctSign === '%', name.trim()]);
}

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Data Dragon ${res.status} for ${url}`);
  return res.json();
}

function build(version, champs, items, spells, runes) {
  const champions = {};
  for (const c of Object.values(champs.data)) {
    champions[c.key] = { id: c.id, key: Number(c.key), name: c.name, title: c.title, tags: c.tags, partype: c.partype, stats: c.stats };
  }
  const itemMap = {};
  for (const [id, it] of Object.entries(items.data)) {
    if (it.maps && it.maps['11'] === false) continue; // Summoner's Rift only
    const tags = it.tags || [];
    const boots = tags.includes('Boots') && (it.gold?.total || 0) >= 900;
    const legendary = !boots && !(it.into && it.into.length) && (it.gold?.total || 0) >= 2000
      && !tags.includes('Consumable') && !tags.includes('Trinket') && it.gold?.purchasable !== false;
    // shop: items a player can actually buy on Summoner's Rift (used by the build maker's item picker)
    const shop = it.gold?.purchasable !== false && it.inStore !== false && !it.requiredChampion && !it.requiredAlly
      && !it.hideFromAll && !tags.includes('Consumable') && !tags.includes('Trinket') && (it.gold?.total || 0) > 0;
    const tier = boots ? 'boots' : legendary ? 'legendary' : (it.into && it.into.length) ? (it.from && it.from.length ? 'epic' : 'basic') : 'other';
    itemMap[id] = { name: it.name, gold: it.gold?.total || 0, legendary, boots, shop, tier, tags, stats: parseStats(it.description) };
  }
  const spellMap = {};
  for (const s of Object.values(spells.data)) spellMap[s.key] = { id: s.id, name: s.name, rift: !s.modes || s.modes.includes('CLASSIC') };
  const runeMap = {};
  const styles = {};
  for (const style of runes) {
    styles[style.id] = { name: style.name, icon: style.icon, slots: style.slots.map((s) => s.runes.map((r) => r.id)) };
    runeMap[style.id] = { name: style.name, icon: style.icon, style: style.id };
    style.slots.forEach((slot, row) => {
      for (const r of slot.runes) runeMap[r.id] = { name: r.name, icon: r.icon, style: style.id, row, keystone: row === 0, desc: String(r.shortDesc || '').replace(/<[^>]+>/g, '').trim() };
    });
  }
  // stat shards aren't in runesReforged.json
  const shards = {
    5008: 'Adaptive Force', 5005: 'Attack Speed', 5007: 'Ability Haste', 5002: 'Armor', 5003: 'Magic Resist',
    5001: 'Scaling Health', 5010: 'Move Speed', 5011: 'Health', 5013: 'Tenacity and Slow Resist',
  };
  for (const [id, name] of Object.entries(shards)) runeMap[id] = { name, shard: true };
  return { version, champions, items: itemMap, spells: spellMap, runes: runeMap, styles };
}

async function load(force = false) {
  if (dd && !force && Date.now() - loadedAt < 6 * 3600e3) return dd;
  try {
    const versions = await fetchJson(`${BASE}/api/versions.json`);
    const v = versions[0];
    const file = path.join(CACHE_DIR, `${v}-v3.json`);
    if (fs.existsSync(file)) {
      dd = JSON.parse(fs.readFileSync(file, 'utf8'));
    } else {
      const root = `${BASE}/cdn/${v}/data/en_GB`;
      const [champs, items, spells, runes] = await Promise.all([
        fetchJson(`${root}/champion.json`), fetchJson(`${root}/item.json`),
        fetchJson(`${root}/summoner.json`), fetchJson(`${root}/runesReforged.json`),
      ]);
      dd = build(v, champs, items, spells, runes);
      fs.writeFileSync(file, JSON.stringify(dd));
    }
  } catch (e) {
    // offline: fall back to the newest cached copy
    const cached = fs.readdirSync(CACHE_DIR).filter((f) => f.endsWith('.json')).sort().pop();
    if (!cached) throw new Error(`Couldn't load Riot's champion data (${e.message}). Check your internet connection.`);
    dd = JSON.parse(fs.readFileSync(path.join(CACHE_DIR, cached), 'utf8'));
  }
  loadedAt = Date.now();
  return dd;
}

const champByKey = (key) => dd?.champions[String(key)];
const champById = (id) => dd && Object.values(dd.champions).find((c) => c.id.toLowerCase() === String(id).toLowerCase());

module.exports = { load, get: () => dd, champByKey, champById, BASE };
