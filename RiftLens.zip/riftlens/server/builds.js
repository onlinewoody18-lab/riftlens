// Build maker: builds you put together yourself, saved on this PC, plus a check of how
// the items, runes and spells you picked have done in collected ranked games.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DATA_DIR } = require('./config');
const stats = require('./stats');
const ddragon = require('./ddragon');

const FILE = path.join(DATA_DIR, 'builds.json');
const MAX_BUILDS = 500;
let saved = null;

function load() {
  if (saved) return saved;
  try { saved = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { saved = []; }
  if (!Array.isArray(saved)) saved = [];
  return saved;
}
function persist() { fs.writeFileSync(FILE, JSON.stringify(saved, null, 1)); }

const bad = (msg) => Object.assign(new Error(msg), { status: 400 });
const ids = (v, max) => (Array.isArray(v) ? v : []).slice(0, max).map((x) => Number(x) || 0);

// Keep only fields we know, with sane types, so a saved file can never hold anything odd.
function clean(b) {
  const dd = ddragon.get();
  const champion = Number(b.champion);
  if (!dd.champions[champion]) throw bad('Unknown champion');
  const runes = b.runes || {};
  return {
    champion,
    name: String(b.name || '').trim().slice(0, 60) || `${dd.champions[champion].name} build`,
    position: ['TOP', 'JUNGLE', 'MIDDLE', 'BOTTOM', 'UTILITY'].includes(b.position) ? b.position : '',
    items: ids(b.items, 6),
    runes: {
      primary: Number(runes.primary) || 0, picks: ids(runes.picks, 4),
      secondary: Number(runes.secondary) || 0, subPicks: ids(runes.subPicks, 2), shards: ids(runes.shards, 3),
    },
    spells: ids(b.spells, 2),
    notes: String(b.notes || '').slice(0, 1000),
  };
}

function list() { return load(); }

function save(body) {
  const all = load();
  const b = clean(body);
  const existing = body.id && all.find((x) => x.id === body.id);
  if (existing) Object.assign(existing, b, { updated: Date.now() });
  else {
    if (all.length >= MAX_BUILDS) throw bad(`You can save up to ${MAX_BUILDS} builds. Delete some first.`);
    all.push({ id: crypto.randomUUID(), ...b, created: Date.now(), updated: Date.now() });
  }
  persist();
  return existing || all[all.length - 1];
}

function remove(id) {
  const all = load();
  const i = all.findIndex((x) => x.id === id);
  if (i >= 0) { all.splice(i, 1); persist(); }
  return { ok: true };
}

// ---- record check ----
function metrics(list) {
  const n = list.length;
  if (!n) return { games: 0 };
  let w = 0;
  for (const r of list) w += r.w;
  return { games: n, winRate: w / n };
}

function check(championId, body) {
  const dd = ddragon.get();
  const { list: all, patches } = stats.championRecords(championId, body.elo);
  const counts = {};
  for (const r of all) counts[r.p] = (counts[r.p] || 0) + 1;
  const positions = Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([p]) => p);
  const pos = body.position || positions[0];
  const recs = all.filter((r) => r.p === pos);
  const out = { position: pos || '', positions, patches, games: recs.length, baseline: metrics(recs) };
  if (!recs.length) return out;

  const items = ids(body.items, 6).filter(Boolean);
  const legendaries = items.filter((id) => dd.items[id]?.legendary);
  const boots = items.find((id) => dd.items[id]?.boots);
  out.items = items.map((id) => {
    if (dd.items[id]?.boots) return { item: id, ...metrics(recs.filter((r) => r.b === id)) };
    if (dd.items[id]?.legendary) return { item: id, ...metrics(recs.filter((r) => r.i.includes(id))) };
    return { item: id, tracked: false };
  });
  // the whole item set together, in any order
  if (legendaries.length) {
    out.together = { count: legendaries.length, ...metrics(recs.filter((r) => legendaries.every((id) => r.i.includes(id)) && (!boots || r.b === boots))) };
    // the largest leading part of the build that has been played, so a rare 5-item set still says something
    for (let n = legendaries.length; n >= 1; n--) {
      const m = metrics(recs.filter((r) => legendaries.slice(0, n).every((id) => r.i.includes(id))));
      if (m.games >= 5 || n === 1) { out.core = { count: n, ...m }; break; }
    }
  }

  const R = body.runes || {};
  const picks = ids(R.picks, 4);
  const ks = picks[0];
  if (ks) {
    const withKs = recs.filter((r) => Number(r.r.split('|')[0].split(':')[1].split(',')[0]) === ks);
    out.keystone = { id: ks, ...metrics(withKs) };
    const runeIds = [...picks.slice(1), ...ids(R.subPicks, 2)].filter(Boolean);
    out.runes = runeIds.map((id) => ({ id, ...metrics(withKs.filter((r) => r.r.split('|').slice(0, 2).some((part) => part.split(':')[1].split(',').map(Number).includes(id)))) }));
    const key = `${Number(R.primary) || 0}:${picks.join(',')}|${Number(R.secondary) || 0}:${ids(R.subPicks, 2).join(',')}|${ids(R.shards, 3).join(',')}`;
    out.page = metrics(recs.filter((r) => r.r === key));
  }
  const sp = ids(body.spells, 2).filter(Boolean);
  if (sp.length === 2) out.spells = metrics(recs.filter((r) => r.s === [...sp].sort((a, b) => a - b).join('-')));
  return out;
}

module.exports = { list, save, remove, check };
