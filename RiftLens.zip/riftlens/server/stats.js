// Aggregates ranked solo games from every rank into champion stats: win/pick/ban rates,
// item builds, runes, summoner spells and lane matchups. Saved to data/stats.json.
// Each patch is split into rank brackets so any page can be filtered by rank.
const fs = require('fs');
const path = require('path');
const { DATA_DIR } = require('./config');
const ddragon = require('./ddragon');

const FILE = path.join(DATA_DIR, 'stats.json');
const POSITIONS = ['TOP', 'JUNGLE', 'MIDDLE', 'BOTTOM', 'UTILITY'];

// Rank brackets. A sampled game is put in the bracket of the player it was found through;
// matchmaking keeps the other nine players close to that rank.
const BRACKETS = {
  low: { label: 'Iron to Silver', tiers: ['IRON', 'BRONZE', 'SILVER'] },
  mid: { label: 'Gold to Platinum', tiers: ['GOLD', 'PLATINUM'] },
  high: { label: 'Emerald to Diamond', tiers: ['EMERALD', 'DIAMOND'] },
  apex: { label: 'Master and above', tiers: ['MASTER', 'GRANDMASTER', 'CHALLENGER'] },
};
const ELO_KEYS = Object.keys(BRACKETS);
const eloList = (elo) => (ELO_KEYS.includes(elo) ? [elo] : ELO_KEYS); // anything else = all ranks

let db = { patches: {} };
try { db = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch {}
// Older versions only collected Master+ games and stored them without brackets.
for (const [patch, P] of Object.entries(db.patches)) {
  if (!P.br) db.patches[patch] = { br: { apex: { games: P.games || 0, champs: P.champs || {}, bans: P.bans || {} } } };
}
const patchGames = (patch, elo) => eloList(elo).reduce((n, b) => n + (db.patches[patch]?.br[b]?.games || 0), 0);

// Compact per-player records for the build planner, newest kept, capped per champion.
const REC_FILE = path.join(DATA_DIR, 'games.json');
const REC_CAP = 6000;
let records = {};
try { records = JSON.parse(fs.readFileSync(REC_FILE, 'utf8')); } catch {}

let dirty = false;
function save() {
  if (!dirty) return;
  fs.writeFileSync(FILE + '.tmp', JSON.stringify(db));
  fs.renameSync(FILE + '.tmp', FILE);
  fs.writeFileSync(REC_FILE + '.tmp', JSON.stringify(records));
  fs.renameSync(REC_FILE + '.tmp', REC_FILE);
  dirty = false;
}
setInterval(save, 30000).unref();

const bump = (obj, key, win) => {
  const e = (obj[key] ||= { g: 0, w: 0 });
  e.g++; if (win) e.w++;
};

function addMatch(match, bracket = 'apex') {
  if (!BRACKETS[bracket]) bracket = 'apex';
  const info = match?.info;
  if (!info || info.queueId !== 420 || info.gameDuration < 300) return false; // ranked solo, no remakes
  const dd = ddragon.get();
  const patch = info.gameVersion.split('.').slice(0, 2).join('.');
  const PP = (db.patches[patch] ||= { br: {} });
  const P = (PP.br[bracket] ||= { games: 0, champs: {}, bans: {} });
  P.games++;

  for (const team of info.teams || []) {
    for (const b of team.bans || []) if (b.championId > 0) P.bans[b.championId] = (P.bans[b.championId] || 0) + 1;
  }
  const parts = info.participants;
  for (const p of parts) {
    const pos = p.teamPosition;
    if (!POSITIONS.includes(pos)) continue;
    const champ = (P.champs[p.championId] ||= {});
    const s = (champ[pos] ||= { g: 0, w: 0, items: {}, builds: {}, boots: {}, runes: {}, spells: {}, vs: {} });
    s.g++; if (p.win) s.w++;

    const slots = [p.item0, p.item1, p.item2, p.item3, p.item4, p.item5].filter(Boolean);
    const legendaries = slots.filter((id) => dd?.items[id]?.legendary);
    const boots = slots.find((id) => dd?.items[id]?.boots);
    for (const id of new Set(legendaries)) bump(s.items, id, p.win);
    if (legendaries.length >= 3) bump(s.builds, legendaries.slice(0, 3).join('-'), p.win);
    if (boots) bump(s.boots, boots, p.win);

    const [prim, sub] = p.perks?.styles || [];
    let runeKey = null;
    if (prim && sub) {
      const sh = p.perks.statPerks || {};
      runeKey = `${prim.style}:${prim.selections.map((x) => x.perk).join(',')}|${sub.style}:${sub.selections.map((x) => x.perk).join(',')}|${[sh.offense, sh.flex, sh.defense].join(',')}`;
      bump(s.runes, runeKey, p.win);
    }
    const spellKey = [p.summoner1Id, p.summoner2Id].sort((a, b) => a - b).join('-');
    bump(s.spells, spellKey, p.win);

    if (runeKey) {
      const list = (records[p.championId] ||= []);
      list.push({
        pt: patch, t: bracket, p: pos, w: p.win ? 1 : 0, r: runeKey, i: legendaries, b: boots || 0, s: spellKey,
        k: p.kills, d: p.deaths, a: p.assists, dm: p.totalDamageDealtToChampions || 0,
        cs: (p.totalMinionsKilled || 0) + (p.neutralMinionsKilled || 0), g: p.goldEarned || 0, du: info.gameDuration,
      });
      if (list.length > REC_CAP) list.splice(0, list.length - REC_CAP);
    }

    const opp = parts.find((o) => o.teamId !== p.teamId && o.teamPosition === pos);
    if (opp) bump(s.vs, opp.championId, p.win);
  }
  dirty = true;
  return true;
}

// ---- queries ----
const patchesByRecency = () => Object.keys(db.patches).sort((a, b) => {
  const [a1, a2] = a.split('.').map(Number); const [b1, b2] = b.split('.').map(Number);
  return b1 - a1 || b2 - a2;
});

// Use the newest patch, adding the previous one while the sample is still small.
function activePatches(elo) {
  const list = patchesByRecency().filter((p) => patchGames(p, elo) > 0);
  if (!list.length) return [];
  const out = [list[0]];
  if (patchGames(list[0], elo) < 400 && list[1]) out.push(list[1]);
  return out;
}

const shrink = (w, g, prior = 50) => (w + prior * 0.5) / (g + prior); // pull small samples toward 50%

function merged(patches, elo) {
  const parts = patches.flatMap((p) => eloList(elo).map((b) => db.patches[p]?.br[b]).filter(Boolean));
  const games = parts.reduce((n, P) => n + P.games, 0);
  const champs = {}; const bans = {};
  const mergeCounts = (into, from) => { for (const [k, v] of Object.entries(from)) { const e = (into[k] ||= { g: 0, w: 0 }); e.g += v.g; e.w += v.w; } };
  for (const P of parts) {
    for (const [id, n] of Object.entries(P.bans)) bans[id] = (bans[id] || 0) + n;
    for (const [cid, posMap] of Object.entries(P.champs)) {
      for (const [pos, s] of Object.entries(posMap)) {
        const t = ((champs[cid] ||= {})[pos] ||= { g: 0, w: 0, items: {}, builds: {}, boots: {}, runes: {}, spells: {}, vs: {} });
        t.g += s.g; t.w += s.w;
        for (const f of ['items', 'builds', 'boots', 'runes', 'spells', 'vs']) mergeCounts(t[f], s[f]);
      }
    }
  }
  return { games, champs, bans };
}

function summary() {
  const patches = patchesByRecency();
  const total = patches.reduce((n, p) => n + patchGames(p), 0);
  const brackets = Object.fromEntries(ELO_KEYS.map((b) => [b, patches.reduce((n, p) => n + patchGames(p, b), 0)]));
  return { totalGames: total, brackets, patches: patches.map((p) => ({ patch: p, games: patchGames(p) })) };
}

function tierList(position, elo) {
  const patches = activePatches(elo);
  if (!patches.length) return { patches, games: 0, rows: [] };
  const { games, champs, bans } = merged(patches, elo);
  const rows = [];
  for (const [cid, posMap] of Object.entries(champs)) {
    const champTotal = Object.values(posMap).reduce((n, s) => n + s.g, 0);
    for (const [pos, s] of Object.entries(posMap)) {
      if (position && position !== 'ALL' && pos !== position) continue;
      const share = s.g / champTotal;
      if (s.g < 8 || share < 0.1) continue; // ignore off-role picks
      rows.push({
        championId: Number(cid), position: pos, games: s.g,
        winRate: s.w / s.g, pickRate: s.g / games, banRate: (bans[cid] || 0) / games,
        score: shrink(s.w, s.g) + Math.min(s.g / games, 0.15) * 0.15,
      });
    }
  }
  rows.sort((a, b) => b.score - a.score);
  const n = rows.length;
  const cut = [[0.05, 'S+'], [0.18, 'S'], [0.4, 'A'], [0.68, 'B'], [0.88, 'C'], [1, 'D']];
  rows.forEach((r, i) => { r.tier = cut.find(([q]) => (i + 1) / n <= q)[1]; });
  return { patches, games, rows };
}

const top = (obj, n, minG = 1) => Object.entries(obj).filter(([, v]) => v.g >= minG)
  .map(([k, v]) => ({ key: k, games: v.g, winRate: v.w / v.g })).sort((a, b) => b.games - a.games).slice(0, n);

function champion(championId, position, elo) {
  const patches = activePatches(elo);
  const { games, champs, bans } = merged(patches, elo);
  const posMap = champs[championId] || {};
  const positions = Object.entries(posMap).map(([pos, s]) => ({ position: pos, games: s.g, winRate: s.w / s.g }))
    .sort((a, b) => b.games - a.games);
  const pos = position && posMap[position] ? position : positions[0]?.position;
  const s = posMap[pos];
  if (!s) return { patches, games, positions, position: null };
  const vs = Object.entries(s.vs).filter(([, v]) => v.g >= 3)
    .map(([cid, v]) => ({ championId: Number(cid), games: v.g, winRate: v.w / v.g, adj: shrink(v.w, v.g, 20) }));
  return {
    patches, games, positions, position: pos,
    stats: { games: s.g, winRate: s.w / s.g, pickRate: s.g / games, banRate: (bans[championId] || 0) / games },
    items: top(s.items, 12), builds: top(s.builds, 5, 2), boots: top(s.boots, 3),
    runes: top(s.runes, 3), spells: top(s.spells, 3),
    best: [...vs].sort((a, b) => b.adj - a.adj).slice(0, 6),
    worst: [...vs].sort((a, b) => a.adj - b.adj).slice(0, 6),
  };
}

// Lane matchup win rate across every stored patch (matchups need lots of data).
function matchup(myChamp, theirChamp, position) {
  let g = 0; let w = 0;
  for (const P of Object.values(db.patches).flatMap((x) => Object.values(x.br))) {
    const posMap = P.champs[myChamp] || {};
    for (const [pos, s] of Object.entries(posMap)) {
      if (position && pos !== position) continue;
      const v = s.vs[theirChamp];
      if (v) { g += v.g; w += v.w; }
    }
  }
  return { games: g, wins: w };
}

function positionCounts(championId) {
  const out = {};
  for (const P of Object.values(db.patches).flatMap((x) => Object.values(x.br))) {
    for (const [pos, s] of Object.entries(P.champs[championId] || {})) out[pos] = (out[pos] || 0) + s.g;
  }
  return out;
}

function reset() { db = { patches: {} }; records = {}; dirty = true; save(); }

// Records for one champion, limited to the active patches unless that leaves too few.
function championRecords(championId, elo) {
  const brs = eloList(elo);
  const all = (records[championId] || []).filter((r) => brs.includes(r.t || 'apex'));
  const patches = activePatches(elo);
  const recent = all.filter((r) => patches.includes(r.pt));
  return { list: recent.length >= 60 ? recent : all, patches: recent.length >= 60 ? patches : 'all stored patches' };
}

module.exports = { BRACKETS, addMatch, tierList, champion, matchup, positionCounts, summary, save, reset, championRecords, POSITIONS };
