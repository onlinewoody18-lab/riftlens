// RiftLens front end: plain JavaScript, no build step.
const view = document.getElementById('view');
const banner = document.getElementById('banner');
let S = null;        // static data: champions, items, runes, spells
let ST = null;       // server status
const POS = { TOP: 'Top', JUNGLE: 'Jungle', MIDDLE: 'Mid', BOTTOM: 'Bot', UTILITY: 'Support' };

// ---------- helpers ----------
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pct = (x, d = 1) => (x == null || isNaN(x) ? '–' : (x * 100).toFixed(d) + '%');
const cdn = (p) => `${S.cdn}/cdn/${S.version}/img/${p}`;
const champ = (key) => S.champions[key] || { id: 'Unknown', name: 'Unknown', key };
const champImg = (key, cls = 'icon') => { const c = S.champions[key]; return c ? `<img class="${cls}" src="${cdn('champion/' + c.id + '.png')}" alt="${esc(c.name)}" title="${esc(c.name)}" loading="lazy">` : `<span class="${cls}"></span>`; };
const itemImg = (id) => (id && S.items[id] !== undefined ? `<img src="${cdn('item/' + id + '.png')}" alt="${esc(S.items[id].name)}" title="${esc(S.items[id].name)}" loading="lazy">` : id ? `<img src="${cdn('item/' + id + '.png')}" alt="" loading="lazy">` : '<span></span>');
const spellImg = (key, cls = 'icon sm') => { const s = S.spells[key]; return s ? `<img class="${cls}" src="${cdn('spell/' + s.id + '.png')}" alt="${esc(s.name)}" title="${esc(s.name)}" loading="lazy">` : `<span class="${cls}"></span>`; };
const runeImg = (id, cls = 'icon sm round') => { const r = S.runes[id]; return r?.icon ? `<img class="${cls}" src="${S.cdn}/cdn/img/${r.icon}" alt="${esc(r.name)}" title="${esc(r.name)}" loading="lazy">` : r ? `<span class="shard" title="${esc(r.name)}">${esc(r.name)}</span>` : ''; };
const kda = (k, d, a) => (d ? ((k + a) / d).toFixed(2) : 'Perfect');
const dur = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const ago = (t) => { const m = (Date.now() - t) / 60000; return m < 60 ? `${Math.max(1, Math.round(m))}m ago` : m < 1440 ? `${Math.round(m / 60)}h ago` : `${Math.round(m / 1440)}d ago`; };
const rankText = (r) => (r ? `${r.tier[0]}${r.tier.slice(1).toLowerCase()}${['MASTER', 'GRANDMASTER', 'CHALLENGER'].includes(r.tier) ? '' : ' ' + r.rank}` : 'Unranked');
const idPath = (riotId) => encodeURIComponent(riotId);
// Rank filter for collected-game stats, remembered per browser.
let ELO = 'all';
try { ELO = localStorage.getItem('riftlens.elo') || 'all'; } catch {}
const eloLabel = () => (ELO === 'all' ? 'all ranks' : ST?.brackets?.[ELO] || ELO);
const wrClass = (wr) => (wr >= 0.53 ? 'good' : wr <= 0.47 ? 'loss' : '');

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, { ...opts, headers: { 'Content-Type': 'application/json' } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

const loading = () => { view.innerHTML = '<div class="spinner" role="status" aria-label="Loading"></div>'; };
const fail = (e) => { view.innerHTML = `<div class="panel empty"><p class="error">${esc(e.message)}</p><p><a href="#/">Back to start</a></p></div>`; };

// Small wrapper so a blocked or private-mode localStorage never breaks the page.
const local = {
  get(k, d = null) { try { const v = localStorage.getItem('riftlens.' + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('riftlens.' + k, JSON.stringify(v)); return true; } catch { return false; } },
};

async function refreshStatus() {
  ST = await api('/status');
  ST.dataPlatform = ST.platform; // region the collected stats come from
  if (ST.hosted) { // online: each visitor's Riot ID and region live in their own browser
    ST.riotId = local.get('riotId', '');
    ST.platform = local.get('platform', ST.platform);
  }
  const sel = document.getElementById('search-region');
  if (!sel.options.length) sel.innerHTML = Object.entries(ST.regions).map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
  sel.value = ST.platform;
  if (ST.hosted && (ST.keyProblem || !ST.hasKey)) { banner.hidden = false; banner.textContent = ST.keyProblem || 'Riot data isn\'t available on this site right now.'; }
  else if (ST.keyProblem) { banner.hidden = false; banner.innerHTML = `${esc(ST.keyProblem)} <a href="#/settings">Open Settings</a>`; }
  else if (!ST.hasKey && !location.hash.startsWith('#/settings')) { banner.hidden = false; banner.innerHTML = 'Add your Riot API key to start. <a href="#/settings">Open Settings</a>'; }
  else banner.hidden = true;
}

// ---------- search ----------
document.getElementById('search').addEventListener('submit', (e) => {
  e.preventDefault();
  const v = document.getElementById('search-input').value.trim();
  if (!v) return;
  location.hash = `#/player/${document.getElementById('search-region').value}/${idPath(v.replace(/\s*#\s*/, '#'))}`;
});

// ---------- pages ----------
async function pageHome() {
  const s = ST;
  const data = s.data.totalGames;
  view.innerHTML = `
    <section class="hero">
      <h1>Know the lobby before the minions spawn.</h1>
      <p>Look up any player's history, scout your live game with a matchup score for every enemy, and pull builds from ranked games at every rank in ${esc(s.regions[s.dataPlatform])}.</p>
      ${s.riotId ? `<a class="btn primary" href="#/live/${s.platform}/${idPath(s.riotId)}">Check my live game</a> <a class="btn" href="#/player/${s.platform}/${idPath(s.riotId)}">My profile</a>`
        : `<a class="btn primary" href="#/settings">${s.hasKey || s.hosted ? 'Add your Riot ID' : 'Set up RiftLens'}</a>`}
    </section>
    ${!s.hasKey && !s.hosted ? `<div class="panel"><h2>Getting your free Riot key</h2><ol class="steps">
      <li>Go to <a href="https://developer.riotgames.com" target="_blank" rel="noopener">developer.riotgames.com</a> and log in with your League account.</li>
      <li>On the dashboard, copy the <b>Development API Key</b> (it starts with RGAPI-). Click <b>Regenerate</b> if it has expired.</li>
      <li>Paste it in <a href="#/settings">Settings</a>. Development keys last 24 hours, so you'll repeat this daily.</li></ol></div>` : ''}
    <div class="feature-row">
      <a class="panel" href="#/live"><h3>Live game</h3><p class="muted small">Ranks, champion mastery and a 0-100 matchup score for each enemy, with your lane opponent highlighted.</p></a>
      <a class="panel" href="#/tierlist"><h3>Tier list</h3><p class="muted small">Win, pick and ban rates by role from ${data ? data.toLocaleString() + ' collected' : 'collected'} ranked games, Iron to Challenger. Filter by rank at the top.</p></a>
      <a class="panel" href="#/champions"><h3>Builds</h3><p class="muted small">Every build ranked by win rate or KDA, plus rune pages, spells and lane matchups.</p></a>
      <a class="panel" href="#/maker"><h3>Build maker</h3><p class="muted small">Pick your own items, runes and spells, see the stats at any level and how those picks have done.</p></a>
    </div>
    <div class="panel"><h3>Game collection</h3>
      <p class="small muted">${s.crawlerEnabled ? `Status: ${esc(s.crawler.status)}. ${s.crawler.processed} games added this session, ${data.toLocaleString()} stored in total.` : 'Paused. Turn it on in Settings to build tier lists and builds.'}
      ${s.crawler.lastError ? `<br><span class="error">Last error: ${esc(s.crawler.lastError)}</span>` : ''}</p>
      <p class="small muted">The personal key allows about 100 requests every 2 minutes, so this collects roughly 2,500 games an hour while RiftLens is open. Tier lists become reliable after a few thousand.</p>
    </div>`;
}

async function pagePlayer(platform, riotId) {
  loading();
  const p = await api(`/player/${platform}/${idPath(riotId)}`);
  const solo = p.ranks.find((r) => r.queueType === 'RANKED_SOLO_5x5');
  const flex = p.ranks.find((r) => r.queueType === 'RANKED_FLEX_SR');
  const rankBlock = (r, label) => `<div class="panel"><p class="muted small">${label}</p>${r
    ? `<p class="rank-big">${rankText(r)} <span class="num">${r.leaguePoints} LP</span></p><p class="small"><span class="win">${r.wins}W</span> <span class="loss">${r.losses}L</span> · ${pct(r.wins / (r.wins + r.losses), 0)} win rate</p>`
    : '<p class="rank-big muted">Unranked</p>'}</div>`;
  const a = p.recent;
  view.innerHTML = `
    <div class="profile-head">
      <div class="avatar"><img src="${cdn('profileicon/' + p.icon + '.png')}" alt=""><span class="lvl">${p.level}</span></div>
      <div><h1>${esc(p.riotId)}</h1><p class="muted">${esc(p.regionLabel)}</p>
        <div class="row" style="margin-top:8px"><a class="btn primary" href="#/live/${platform}/${idPath(p.riotId)}">Live game</a>
        <button class="btn" id="refresh">Refresh</button></div></div>
    </div>
    <div class="grid-2">
      <aside class="stack">
        ${rankBlock(solo, 'Ranked Solo/Duo')}${rankBlock(flex, 'Ranked Flex')}
        <div class="panel"><h3>Last ${a.games} games</h3>
          <p class="num" style="font-size:28px"><span>${a.games ? pct(a.wins / a.games, 0) : '–'}</span> <span class="muted small">${a.wins}W ${a.games - a.wins}L</span></p>
          <p class="small">${a.games ? `${(a.kills / a.games).toFixed(1)} / ${(a.deaths / a.games).toFixed(1)} / ${(a.assists / a.games).toFixed(1)} · <b>${kda(a.kills, a.deaths, a.assists)} KDA</b><br>${a.csPerMin.toFixed(1)} CS/min · ${pct(a.kp, 0)} kill participation` : 'No games yet.'}</p>
          ${p.roles.length ? `<div class="row wrap small" style="margin-top:8px">${p.roles.map((r) => `<span class="pill">${POS[r.position] || r.position} ${r.games}</span>`).join('')}</div>` : ''}
        </div>
        <div class="panel"><h3>Champions</h3>
          ${p.champions.slice(0, 7).map((c) => `<div class="row" style="padding:5px 0"><a href="#/champion/${c.championId}">${champImg(c.championId)}</a>
            <div style="flex:1"><div>${esc(champ(c.championId).name)}</div><div class="small muted">${kda(c.k, c.d, c.a)} KDA</div></div>
            <div class="small" style="text-align:right"><span>${pct(c.wins / c.games, 0)}</span><br><span class="muted">${c.games} game${c.games > 1 ? 's' : ''}</span></div></div>`).join('') || '<p class="muted small">No games yet.</p>'}
        </div>
        <div class="panel"><h3>Highest mastery</h3><div class="row wrap">
          ${p.mastery.map((m) => `<div style="text-align:center">${champImg(m.championId, 'icon lg')}<div class="small num">${(m.points / 1000).toFixed(0)}k</div></div>`).join('')}
        </div></div>
      </aside>
      <section>${p.matches.map(matchRow).join('') || '<div class="panel empty">No recent matches.</div>'}</section>
    </div>`;
  document.getElementById('refresh').onclick = () => route(true);
}

function matchRow(m) {
  const cls = m.remake ? 'remake' : m.win ? 'won' : 'lost';
  const t100 = m.players.filter((x) => x.teamId === 100); const t200 = m.players.filter((x) => x.teamId === 200);
  const link = (x) => `<a class="${x.isMe ? 'me' : ''}" href="#/player/${ST.platform}/${idPath(x.name + '#' + x.tag)}">${champImg(x.championId, '')}${esc(x.name)}</a>`;
  return `<article class="match ${cls}">
    <div class="edge"></div>
    <div class="small"><b class="${m.remake ? 'muted' : m.win ? 'win' : 'loss'}">${m.remake ? 'Remake' : m.win ? 'Victory' : 'Defeat'}</b><br>${esc(m.queue)}<br><span class="muted">${dur(m.duration)} · ${ago(m.endedAt)}</span></div>
    <div class="row">${champImg(m.championId, 'icon lg')}</div>
    <div><div class="kda">${m.kills} / <span class="loss">${m.deaths}</span> / ${m.assists}</div>
      <div class="small muted">${kda(m.kills, m.deaths, m.assists)} KDA · ${m.cs} CS (${m.csPerMin.toFixed(1)})</div>
      <div class="row small" style="gap:4px;margin-top:4px"><span class="stack-icons">${spellImg(m.spells[0])}${spellImg(m.spells[1])}</span><span class="stack-icons">${runeImg(m.keystone)}${runeImg(m.subStyle)}</span>${m.multikill ? `<span class="pill">${m.multikill}</span>` : ''}</div></div>
    <div><div class="items">${m.items.map(itemImg).join('')}</div><div class="small muted" style="margin-top:4px">${pct(m.kp, 0)} KP · ${m.damage.toLocaleString()} dmg · ${m.vision} vision</div></div>
    <div class="teams hide-sm">${[0, 1, 2, 3, 4].map((i) => (t100[i] ? link(t100[i]) : '<span></span>') + (t200[i] ? link(t200[i]) : '<span></span>')).join('')}</div>
  </article>`;
}

async function pageLiveEntry() {
  if (ST.riotId) { location.replace(`#/live/${ST.platform}/${idPath(ST.riotId)}`); return; }
  view.innerHTML = `<div class="panel" style="max-width:520px"><h2>Live game</h2>
    <p class="muted">Enter the Riot ID of someone in a game (or save yours in Settings to skip this step).</p>
    <form id="lf" class="row"><input class="field" id="lid" placeholder="Name#TAG" style="flex:1;padding:9px 12px;background:var(--rift);border:1px solid var(--line);border-radius:4px"><button class="btn primary">Find game</button></form></div>`;
  document.getElementById('lf').onsubmit = (e) => { e.preventDefault(); const v = document.getElementById('lid').value.trim(); if (v) location.hash = `#/live/${ST.platform}/${idPath(v)}`; };
}

function dial(score) {
  const C = 2 * Math.PI * 70; const arc = C * 0.75;
  const color = score >= 55 ? 'var(--blue)' : score <= 45 ? 'var(--red)' : 'var(--accent)';
  return `<div class="dial" role="img" aria-label="Lane matchup score ${score} out of 100">
    <svg viewBox="0 0 160 160"><circle class="track" cx="80" cy="80" r="70" fill="none" stroke-width="12" stroke-linecap="round" stroke-dasharray="${arc} ${C}"/>
    <circle class="val" cx="80" cy="80" r="70" fill="none" stroke="${color}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${arc} ${C}" stroke-dashoffset="${arc}" data-target="${arc * (1 - score / 100)}"/></svg>
    <div class="read"><b style="color:${color}">${score}</b><span>lane score</span></div></div>`;
}

function breakdown(mu) {
  return `<div class="breakdown">${mu.factors.map((f) => {
    const w = Math.abs(f.edge) * 50; const left = f.edge >= 0 ? 50 : 50 - w;
    return `<div class="factor"><span>${esc(f.label)}</span><div class="edge-bar" title="${esc(f.detail)}"><i style="left:${left}%;width:${w}%;background:${f.edge >= 0 ? 'var(--blue)' : 'var(--red)'}"></i></div><span class="num ${f.edge > 0 ? 'win' : f.edge < 0 ? 'loss' : ''}">${f.edge > 0 ? '+' : ''}${Math.round(f.edge * 100)}</span></div>
      <div class="small muted" style="margin:-2px 0 6px">${esc(f.detail)}</div>`;
  }).join('')}<p class="small muted">Each bar runs from them ahead (left) to you ahead (right). Factors without data are left out.</p></div>`;
}

async function pageLive(platform, riotId) {
  loading();
  const g = await api(`/live/${platform}/${idPath(riotId)}`);
  if (!g.inGame) {
    view.innerHTML = `<div class="panel empty"><h2>${esc(g.riotId)} isn't in a game right now</h2>
      <p>Live data appears once the game has loaded past the loading screen. Champion select isn't visible to the Riot API.</p>
      <button class="btn primary" id="again">Check again</button> <a class="btn" href="#/player/${platform}/${idPath(g.riotId)}">View profile</a></div>`;
    document.getElementById('again').onclick = () => route(true);
    return;
  }
  const mine = g.players.filter((p) => p.teamId === g.myTeam);
  const theirs = g.players.filter((p) => p.teamId !== g.myTeam);
  const order = (list) => [...list].sort((a, b) => Object.keys(POS).indexOf(a.role) - Object.keys(POS).indexOf(b.role));
  const byPuuid = Object.fromEntries(g.matchups.map((m) => [m.puuid, m]));
  const me = g.players.find((p) => p.puuid === g.myPuuid);
  const lane = g.matchups.find((m) => m.laneOpponent);
  const laneOpp = lane && g.players.find((p) => p.puuid === lane.puuid);
  const side = (id) => (id === 100 ? 'blue' : 'red');
  const avg = (pts) => { if (pts == null) return 'Unranked'; const tiers = ['Iron', 'Bronze', 'Silver', 'Gold', 'Platinum', 'Emerald', 'Diamond']; return pts >= 2800 ? 'Master+' : `${tiers[Math.floor(pts / 400)]} ${['IV', 'III', 'II', 'I'][Math.floor((pts % 400) / 100)]}`; };

  const playerRow = (p, enemy) => {
    const mu = byPuuid[p.puuid];
    return `<div class="player ${p.puuid === g.myPuuid ? 'me' : ''} ${mu?.laneOpponent ? 'lane' : ''}">
      <div style="position:relative">${champImg(p.championId, 'icon lg')}</div>
      <div style="min-width:0"><div class="name">${p.puuid ? `<a href="#/player/${platform}/${idPath(p.riotId)}">${esc(p.riotId)}</a>` : esc(p.riotId)}</div>
        <div class="small muted">${esc(champ(p.championId).name)} · ${POS[p.role] || '?'} · ${esc(p.rankLabel)}</div>
        <div class="row small" style="gap:4px;margin-top:3px">${spellImg(p.spells[0])}${spellImg(p.spells[1])}${runeImg(p.keystone)}${runeImg(p.subStyle)}
          <span class="muted">${p.masteryPoints ? `${(p.masteryPoints / 1000).toFixed(0)}k mastery` : 'Mastery 0'}</span>
          ${p.rank ? `<span class="muted">· ${pct(p.rank.wins / (p.rank.wins + p.rank.losses), 0)} WR</span>` : ''}</div></div>
      ${enemy && mu ? `<button class="score-chip" aria-expanded="false" data-p="${esc(p.puuid)}" title="${esc(mu.verdict)}. Click for breakdown" style="color:${mu.score >= 55 ? 'var(--blue)' : mu.score <= 45 ? 'var(--red)' : 'var(--accent)'}">${mu.score}</button>` : '<span></span>'}
      <div class="bd" data-for="${esc(p.puuid)}" hidden style="grid-column:1/-1">${enemy && mu ? breakdown(mu) : ''}</div>
    </div>`;
  };

  view.innerHTML = `
    <div class="live-head">
      ${lane ? dial(lane.score) : ''}
      <div><h1>${lane ? esc(lane.verdict) : 'Live game'}</h1>
        <p class="muted" style="margin:6px 0 10px">${lane && laneOpp ? `${esc(champ(me.championId).name)} vs ${esc(champ(laneOpp.championId).name)} in ${POS[me.role] || 'lane'} · ` : ''}${esc(g.queue)} · ${dur(Math.max(0, (Date.now() - g.startedAt) / 1000))} in</p>
        <p class="small">Your team averages <b>${avg(g.teamAvgRank[g.myTeam])}</b>, enemies average <b>${avg(g.teamAvgRank.enemy)}</b>. Click any score to see why.</p>
        <div class="row" style="margin-top:10px"><button class="btn" id="again">Refresh</button></div></div>
    </div>
    <div class="teams-live">
      <section class="side ${side(g.myTeam)}"><h3>Your team</h3>${order(mine).map((p) => playerRow(p, false)).join('')}</section>
      <section class="side ${side(theirs[0]?.teamId)}"><h3>Enemy team · matchup scores</h3>${order(theirs).map((p) => playerRow(p, true)).join('')}</section>
    </div>
    ${g.bans.length ? `<div class="panel" style="margin-top:16px"><h3>Bans</h3><div class="row wrap" style="margin-top:8px">${g.bans.filter((b) => b.championId > 0).map((b) => champImg(b.championId)).join('')}</div></div>` : ''}
    <p class="small muted" style="margin-top:16px">Roles are estimated from each champion's usual position and Smite. Scores weigh lane matchup win rate (30%), rank (30%), mastery on the champion (20%) and season win rate (20%).</p>`;

  requestAnimationFrame(() => document.querySelectorAll('.dial .val').forEach((c) => { c.style.strokeDashoffset = c.dataset.target; }));
  document.getElementById('again').onclick = () => route(true);
  view.querySelectorAll('.score-chip').forEach((b) => b.onclick = () => {
    const panel = view.querySelector(`.bd[data-for="${CSS.escape(b.dataset.p)}"]`);
    panel.hidden = !panel.hidden; b.setAttribute('aria-expanded', String(!panel.hidden));
  });
}

let tierSort = { key: 'score', dir: -1 };
async function pageTierList(pos = 'ALL') {
  loading();
  const t = await api('/tierlist?' + new URLSearchParams({ position: pos, elo: ELO }));
  const rows = [...t.rows].sort((a, b) => {
    const k = tierSort.key;
    const va = k === 'name' ? champ(a.championId).name : a[k]; const vb = k === 'name' ? champ(b.championId).name : b[k];
    return (va > vb ? 1 : va < vb ? -1 : 0) * tierSort.dir;
  });
  const th = (k, label) => `<th data-k="${k}" aria-sort="${tierSort.key === k ? (tierSort.dir > 0 ? 'ascending' : 'descending') : 'none'}">${label}${tierSort.key === k ? (tierSort.dir > 0 ? ' ▲' : ' ▼') : ''}</th>`;
  view.innerHTML = `
    <div class="row wrap" style="justify-content:space-between;margin-bottom:16px"><div><h1>Tier list</h1>
      <p class="muted small">${t.games ? `Ranked Solo, ${esc(eloLabel())}, patch ${t.patches.join(' + ')} · ${t.games.toLocaleString()} games` : ''}</p></div>
      <nav class="tabs">${['ALL', ...Object.keys(POS)].map((p) => `<a href="#/tierlist/${p}" class="${p === pos ? 'on' : ''}">${p === 'ALL' ? 'All roles' : POS[p]}</a>`).join('')}</nav></div>
    ${!t.rows.length ? `<div class="panel empty"><p>No games collected yet.</p><p class="small">RiftLens gathers ranked games in the background while it's open. Check back in 10-15 minutes${ST.hasKey ? '' : ', after adding your API key in <a href="#/settings">Settings</a>'}.</p></div>` : `
    ${t.games < 2000 ? `<p class="small muted" style="margin-bottom:10px">Small sample so far (${t.games} games). Tiers will settle as more games come in.</p>` : ''}
    <div class="panel" style="padding:0;overflow-x:auto"><table>
      <thead><tr><th data-k="score" aria-sort="none">Tier</th>${th('name', 'Champion')}<th>Role</th>${th('winRate', 'Win rate')}${th('pickRate', 'Pick rate')}${th('banRate', 'Ban rate')}${th('games', 'Games')}</tr></thead>
      <tbody>${rows.map((r) => `<tr class="clickable" data-href="#/champion/${r.championId}/${r.position}">
        <td><span class="tier t-${r.tier.replace('+', 'p')}">${r.tier}</span></td>
        <td><div class="row">${champImg(r.championId)}<a href="#/champion/${r.championId}/${r.position}">${esc(champ(r.championId).name)}</a></div></td>
        <td class="muted">${POS[r.position]}</td><td class="num ${wrClass(r.winRate)}">${pct(r.winRate)}</td>
        <td class="num">${pct(r.pickRate)}</td><td class="num">${pct(r.banRate)}</td><td class="num muted">${r.games}</td></tr>`).join('')}</tbody>
    </table></div>`}`;
  view.querySelectorAll('th[data-k]').forEach((h) => h.onclick = () => {
    tierSort = { key: h.dataset.k, dir: tierSort.key === h.dataset.k ? -tierSort.dir : h.dataset.k === 'name' ? 1 : -1 };
    pageTierList(pos);
  });
  view.querySelectorAll('tr[data-href]').forEach((r) => r.onclick = (e) => { if (e.target.tagName !== 'A') location.hash = r.dataset.href; });
}

async function pageChampions() {
  const list = Object.values(S.champions).sort((a, b) => a.name.localeCompare(b.name));
  view.innerHTML = `<div class="row wrap" style="justify-content:space-between;margin-bottom:16px"><h1>Champions</h1>
    <input id="cf" placeholder="Filter champions" aria-label="Filter champions" style="padding:9px 12px;background:var(--deck);border:1px solid var(--line);border-radius:4px;min-width:220px"></div>
    <div class="champ-grid">${list.map((c) => `<a href="#/champion/${c.key}" data-n="${esc(c.name.toLowerCase())}"><img src="${cdn('champion/' + c.id + '.png')}" alt="" loading="lazy">${esc(c.name)}</a>`).join('')}</div>`;
  const f = document.getElementById('cf');
  f.focus();
  f.oninput = () => view.querySelectorAll('.champ-grid a').forEach((a) => { a.hidden = !a.dataset.n.includes(f.value.toLowerCase()); });
}

function runePage(key) {
  const [prim, sub, shards] = key.split('|');
  const [ps, pr] = prim.split(':'); const [ss, sr] = sub.split(':');
  const p = pr.split(','); const s = sr.split(',');
  return `<div class="rune-tree">${runeImg(Number(ps), 'icon sm')}${runeImg(Number(p[0]), 'key')}${p.slice(1).map((r) => runeImg(Number(r), '')).join('')}
    <span style="width:10px"></span>${runeImg(Number(ss), 'icon sm')}${s.map((r) => runeImg(Number(r), '')).join('')}</div>
    <div class="shard">${shards.split(',').map((x) => esc(S.runes[x]?.name || '')).filter(Boolean).join(' / ')}</div>`;
}

let rankSort = 'winrate';

async function pageChampion(key, pos) {
  loading();
  const c = champ(key);
  const d = await api(`/champion/${key}?` + new URLSearchParams({ position: pos || '', elo: ELO }));
  const statLine = (label, html) => `<div><div class="muted small">${label}</div><div class="num" style="font-size:24px">${html}</div></div>`;
  const line = (left, x) => `<div class="build-line">${left}<div style="margin-left:auto;text-align:right" class="small"><span class="num ${wrClass(x.winRate)}" style="font-size:16px">${pct(x.winRate)}</span><br><span class="muted">${x.games} games</span></div></div>`;
  const mu = (list) => list.map((m) => `<a href="#/champion/${m.championId}">${champImg(m.championId)}<span style="flex:1">${esc(champ(m.championId).name)}</span><span class="num ${wrClass(m.winRate)}">${pct(m.winRate)}</span><span class="small muted" style="width:60px;text-align:right">${m.games} games</span></a>`).join('') || '<p class="small muted">Not enough games yet.</p>';
  view.innerHTML = `
    <div class="row wrap" style="gap:18px;margin-bottom:18px">
      ${champImg(key, 'icon lg')}
      <div style="flex:1"><h1>${esc(c.name)}</h1><p class="muted">${esc(c.title || '')}</p></div>
      <a class="btn primary" href="#/build/${key}${d.position ? '/' + d.position : ''}">Plan a build</a>
      ${d.positions.length ? `<nav class="tabs">${d.positions.map((p) => `<a class="${p.position === d.position ? 'on' : ''}" href="#/champion/${key}/${p.position}">${POS[p.position]} <span class="muted small">${p.games}</span></a>`).join('')}</nav>` : ''}
    </div>
    ${!d.position ? `<div class="panel empty"><p>No games on ${esc(c.name)} collected yet for ${esc(eloLabel())}.</p><p class="small">Builds fill in as RiftLens collects games in the background.</p></div>` : `
    <div class="panel row wrap" style="gap:40px">
      ${statLine('Win rate', `<span class="${wrClass(d.stats.winRate)}">${pct(d.stats.winRate)}</span>`)}${statLine('Pick rate', pct(d.stats.pickRate))}${statLine('Ban rate', pct(d.stats.banRate))}${statLine('Games', d.stats.games.toLocaleString())}
      <p class="small muted" style="flex-basis:100%;margin:0">Ranked Solo, ${esc(eloLabel())}, patch ${d.patches.join(' + ')}.</p>
    </div>
    <div class="panel" style="margin-top:16px;padding:0;overflow-x:auto" id="ranked"></div>
    <div class="grid-2 even" style="margin-top:16px">
      <div class="stack">
        <div class="panel"><h3>Rune pages</h3>${d.runes.map((r) => line(`<div>${runePage(r.key)}</div>`, r)).join('') || '<p class="small muted">No data.</p>'}</div>
        <div class="panel"><h3>Summoner spells</h3>${d.spells.map((s) => line(`<div class="row">${s.key.split('-').map((k) => spellImg(k, 'icon')).join('')}</div>`, s)).join('')}</div>
        <div class="panel"><h3>Strong against</h3><div class="mu-list">${mu(d.best)}</div></div>
        <div class="panel"><h3>Weak against</h3><div class="mu-list">${mu(d.worst)}</div></div>
      </div>
      <div class="stack">
        <div class="panel"><h3>Core builds</h3><p class="small muted">First three completed items, in inventory order.</p>${d.builds.map((b) => line(`<div class="items">${b.key.split('-').map(itemImg).join('')}</div>`, b)).join('') || '<p class="small muted">Not enough games yet.</p>'}</div>
        <div class="panel"><h3>Boots</h3>${d.boots.map((b) => line(`<div class="row"><div class="items">${itemImg(b.key)}</div><span class="small">${esc(S.items[b.key]?.name || '')}</span></div>`, b)).join('') || '<p class="small muted">No data.</p>'}</div>
        <div class="panel"><h3>Popular items</h3>${d.items.map((i) => line(`<div class="row"><div class="items">${itemImg(i.key)}</div><span class="small">${esc(S.items[i.key]?.name || '')}</span></div>`, i)).join('')}</div>
      </div>
    </div>`}`;
  if (d.position) loadRanked(key, d.position);
}

async function loadRanked(key, pos) {
  const box = document.getElementById('ranked');
  if (!box) return;
  const r = await api(`/rankings/${key}?` + new URLSearchParams({ position: pos, elo: ELO, sort: rankSort })).catch((e) => ({ error: e.message }));
  if (!document.body.contains(box)) return;
  const sorts = [['winrate', 'Win rate'], ['kda', 'KDA'], ['games', 'Most played'], ['damage', 'Damage']];
  const kdaTxt = (x) => `${x.kills.toFixed(1)} / ${x.deaths.toFixed(1)} / ${x.assists.toFixed(1)}`;
  box.innerHTML = `<div style="padding:16px 16px 0"><div class="row wrap" style="justify-content:space-between;gap:10px">
      <div><h3 style="margin:0">All builds, ranked</h3><p class="small muted" style="margin:4px 0 0">Every set of first three completed items players went, highest first. Builds with fewer than ${r.minGames || 3} games are hidden. Click Edit to open one in the build maker.</p></div>
      <nav class="tabs">${sorts.map(([k, l]) => `<a href="#" data-sort="${k}" class="${rankSort === k ? 'on' : ''}">${l}</a>`).join('')}</nav></div></div>
    ${r.error ? `<p class="error small" style="padding:16px">${esc(r.error)}</p>` : !r.rows?.length ? '<p class="small muted" style="padding:16px">Not enough games with three completed items yet.</p>' : `
    <table><thead><tr><th>#</th><th>Items</th><th>Keystone</th><th>Games</th><th>Win rate</th><th>KDA</th><th class="hide-sm">K / D / A</th><th class="hide-sm">Dmg/min</th><th></th></tr></thead>
    <tbody>${r.rows.map((x, i) => {
      const ks = Number((x.runes || '').split('|')[0].split(':')[1]?.split(',')[0]);
      return `<tr><td class="muted num">${i + 1}</td><td><div class="items">${x.items.map(itemImg).join('')}${x.boots ? itemImg(x.boots) : ''}</div></td>
        <td>${ks ? runeImg(ks, 'icon sm round') : ''}</td><td class="num">${x.games}</td>
        <td class="num ${wrClass(x.winRate)}">${pct(x.winRate)}</td><td class="num">${x.kda.toFixed(2)}</td>
        <td class="num hide-sm muted">${kdaTxt(x)}</td><td class="num hide-sm">${Math.round(x.dpm)}</td>
        <td><a class="btn small-btn" href="${makerHash(rowToBuild(Number(key), pos, x))}">Edit</a></td></tr>`;
    }).join('')}</tbody></table>`}`;
  box.querySelectorAll('[data-sort]').forEach((a) => a.onclick = (e) => { e.preventDefault(); rankSort = a.dataset.sort; loadRanked(key, pos); });
}

// Online version: nothing is stored on the server, so settings are just this browser's.
function pageSettingsOnline() {
  const s = ST;
  view.innerHTML = `
    <h1 style="margin-bottom:16px">Settings</h1>
    <form class="panel" id="sf" style="max-width:620px">
      <p class="small muted" style="margin-top:0">These are saved only in this browser, so the app can open your profile and live game in one click.</p>
      <label class="field"><span>Your region</span><select id="plat">${Object.entries(s.regions).map(([k, v]) => `<option value="${k}" ${k === s.platform ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label class="field"><span>Your Riot ID</span><input id="rid" value="${esc(s.riotId)}" placeholder="Name#TAG"></label>
      <div class="row"><button class="btn primary" type="submit">Save</button><span id="msg" class="small" role="status"></span></div>
    </form>
    <div class="panel" style="max-width:620px"><h3>Collected data</h3>
      <p class="small muted">Tier lists and builds use ${s.data.totalGames.toLocaleString()} ranked games collected from ${esc(s.regions[s.dataPlatform])} (${Object.entries(s.data.brackets || {}).map(([b, n]) => `${esc(s.brackets[b])}: ${n.toLocaleString()}`).join(', ')}).</p></div>`;
  document.getElementById('sf').onsubmit = async (e) => {
    e.preventDefault();
    local.set('platform', document.getElementById('plat').value);
    local.set('riotId', document.getElementById('rid').value.trim());
    await refreshStatus();
    const msg = document.getElementById('msg'); msg.textContent = 'Saved in this browser.'; msg.className = 'small good';
  };
}

async function pageSettings() {
  const s = ST;
  if (s.hosted) return pageSettingsOnline();
  view.innerHTML = `
    <h1 style="margin-bottom:16px">Settings</h1>
    <form class="panel" id="sf" style="max-width:620px">
      <label class="field"><span>Riot API key</span>
        <input id="key" type="password" placeholder="${s.hasKey ? 'Saved (' + esc(s.keyHint) + '). Paste a new key to replace it' : 'RGAPI-xxxxxxxx-xxxx-…'}" autocomplete="off">
      </label>
      <p class="small muted" style="margin:-8px 0 14px">RiftLens runs only on this PC for your own use, as Riot's rules require for development keys. Get one at <a href="https://developer.riotgames.com" target="_blank" rel="noopener">developer.riotgames.com</a>. It's stored only on this PC and expires every 24 hours.</p>
      <label class="field"><span>Region</span><select id="plat">${Object.entries(s.regions).map(([k, v]) => `<option value="${k}" ${k === s.platform ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label class="field"><span>Your Riot ID</span><input id="rid" value="${esc(s.riotId)}" placeholder="Name#TAG"></label>
      <label class="row" style="margin-bottom:16px"><input type="checkbox" id="crawl" ${s.crawlerEnabled ? 'checked' : ''}> Collect ranked games from every rank in the background for the tier list and builds</label>
      <div class="row"><button class="btn primary" type="submit">Save settings</button><span id="msg" class="small" role="status"></span></div>
    </form>
    <div class="panel" style="max-width:620px"><h3>Collected data</h3>
      <p class="small muted">${s.data.totalGames.toLocaleString()} games stored (${Object.entries(s.data.brackets || {}).map(([b, n]) => `${esc(s.brackets[b])}: ${n.toLocaleString()}`).join(', ')})${s.data.patches.length ? ' across patches ' + s.data.patches.map((p) => `${p.patch} (${p.games})`).join(', ') : ''}.</p>
      <button class="btn danger" id="reset">Delete collected games</button></div>`;
  document.getElementById('sf').onsubmit = async (e) => {
    e.preventDefault();
    const msg = document.getElementById('msg');
    const body = { platform: document.getElementById('plat').value, riotId: document.getElementById('rid').value, crawler: document.getElementById('crawl').checked };
    const key = document.getElementById('key').value.trim();
    if (key) body.apiKey = key;
    msg.className = 'small'; msg.textContent = 'Saving…';
    try { await api('/settings', { method: 'POST', body: JSON.stringify(body) }); await refreshStatus(); document.getElementById('key').value = ''; msg.textContent = key ? 'Saved. Key accepted by Riot.' : 'Saved.'; msg.className = 'small good'; }
    catch (err) { msg.textContent = err.message; msg.className = 'small error'; }
  };
  document.getElementById('reset').onclick = async () => {
    if (!confirm('Delete all collected games? The tier list and builds will start from zero.')) return;
    await api('/stats/reset', { method: 'POST' }); await refreshStatus(); pageSettings();
  };
}

// ---------- build planner ----------
function buildHash(key, pos, q) {
  const p = new URLSearchParams();
  if (q.ks) p.set('ks', q.ks);
  if (q.mode && q.mode !== 'winrate') p.set('mode', q.mode);
  if (q.fixed && q.fixed.some(Boolean)) p.set('fixed', q.fixed.map((x) => x || '').join(','));
  const s = p.toString();
  return `#/build/${key}${pos ? '/' + pos : ''}${s ? '?' + s : ''}`;
}

const metricCells = (m, base) => {
  const d = base ? m.winRate - base : 0;
  return `<td class="num">${m.games}</td><td class="num">${pct(m.share, 0)}</td>
    <td class="num ${wrClass(m.winRate)}">${pct(m.winRate)}${base && m.games >= 10 ? ` <span class="small muted">${d >= 0 ? '+' : ''}${(d * 100).toFixed(1)}</span>` : ''}</td>
    <td class="num hide-sm">${m.kda?.toFixed(2) ?? '–'}</td><td class="num hide-sm">${m.dpm ? Math.round(m.dpm) : '–'}</td><td class="num hide-sm">${m.cspm?.toFixed(1) ?? '–'}</td>`;
};

async function pageBuild(key, pos, q) {
  const list = Object.values(S.champions).sort((a, b) => a.name.localeCompare(b.name));
  if (!key) {
    view.innerHTML = `<h1 style="margin-bottom:6px">Build planner</h1>
      <p class="muted" style="margin-bottom:16px">Pick a champion, then a keystone. RiftLens builds the rune page and item path with the best record in collected ranked games (use the rank filter at the top), and you can lock any item to build around it.</p>
      <input id="cf" placeholder="Filter champions" aria-label="Filter champions" style="padding:9px 12px;background:var(--deck);border:1px solid var(--line);border-radius:4px;min-width:220px;margin-bottom:16px">
      <div class="champ-grid">${list.map((c) => `<a href="#/build/${c.key}" data-n="${esc(c.name.toLowerCase())}"><img src="${cdn('champion/' + c.id + '.png')}" alt="" loading="lazy">${esc(c.name)}</a>`).join('')}</div>`;
    const f = document.getElementById('cf'); f.focus();
    f.oninput = () => view.querySelectorAll('.champ-grid a').forEach((a) => { a.hidden = !a.dataset.n.includes(f.value.toLowerCase()); });
    return;
  }
  loading();
  const fixed = (q.get('fixed') || '').split(',').map((x) => x || '');
  const state = { ks: q.get('ks') || '', mode: q.get('mode') || 'winrate', fixed };
  const d = await api(`/planner/${key}?` + new URLSearchParams({ position: pos || '', keystone: state.ks, mode: state.mode, fixed: fixed.join(','), elo: ELO }));
  const c = champ(key);
  const go = (patch) => { location.hash = buildHash(key, patch.pos ?? d.position, { ...state, ...patch }); };

  // keystone picker: every keystone in the game, grouped by tree, with this champ's games on it
  const ksGames = Object.fromEntries((d.keystones || []).map((k) => [k.id, k]));
  const trees = Object.entries(S.styles).filter(([, s]) => s.slots);
  const picker = `<div class="row wrap" style="gap:18px">${trees.map(([sid, s]) => `<div><div class="small muted" style="margin-bottom:4px">${esc(s.name)}</div><div class="row" style="gap:6px">
    ${s.slots[0].map((id) => { const k = ksGames[id]; const on = d.keystone === id;
      return `<button class="ks ${on ? 'on' : ''}" data-ks="${id}" title="${esc(S.runes[id]?.name)}${k ? ` · ${k.games} games, ${pct(k.winRate)} win rate` : ' · no games yet'}" style="opacity:${k ? 1 : 0.35}">${runeImg(id, 'icon')}</button>`; }).join('')}</div></div>`).join('')}</div>`;

  const head = `
    <div class="row wrap" style="gap:18px;margin-bottom:16px">
      <a href="#/build" title="Change champion">${champImg(key, 'icon lg')}</a>
      <div style="flex:1"><h1>${esc(c.name)} build planner</h1><p class="muted small">${d.totalGames ? `${d.totalGames} games on ${esc(c.name)}, ${esc(eloLabel())} · patch ${Array.isArray(d.patches) ? d.patches.join(' + ') : d.patches}` : ''}</p></div>
      ${d.positions.length ? `<nav class="tabs">${d.positions.map((p) => `<a class="${p.position === d.position ? 'on' : ''}" href="${buildHash(key, p.position, {})}">${POS[p.position]} <span class="muted small">${p.games}</span></a>`).join('')}</nav>` : ''}
    </div>`;

  if (d.empty) {
    view.innerHTML = head + `<div class="panel empty"><p>No games on ${esc(c.name)} collected yet for ${esc(eloLabel())}.</p><p class="small">The planner fills in as RiftLens collects games. Popular champions show up within 15-30 minutes; rarer picks take longer.</p></div>`;
    return;
  }

  const ksName = esc(S.runes[d.keystone]?.name || 'this keystone');
  const keystoneTable = `<div class="panel" style="padding:0;overflow-x:auto"><div style="padding:16px 16px 0"><h3>Keystone comparison</h3>
    <p class="small muted">Every keystone ${esc(c.name)} ${POS[d.position]} players took. Win rate difference is against the role average of ${pct(d.roleBaseline.winRate)}. Click a row to plan with it.</p></div>
    <table><thead><tr><th>Keystone</th><th>Games</th><th>Pick</th><th>Win rate</th><th class="hide-sm">KDA</th><th class="hide-sm">Dmg/min</th><th class="hide-sm">CS/min</th></tr></thead>
    <tbody>${d.keystones.map((k) => `<tr class="clickable ${k.id === d.keystone ? 'sel' : ''}" data-ks="${k.id}"><td><div class="row">${runeImg(k.id, 'icon')}${esc(S.runes[k.id]?.name || k.id)}</div></td>${metricCells(k, d.roleBaseline.winRate)}</tr>`).join('')}</tbody></table></div>`;

  if (d.noKeystoneData) {
    view.innerHTML = head + `<div class="panel" style="margin-bottom:16px">${picker}</div>
      <div class="panel empty"><p>No collected games where ${esc(c.name)} ${POS[d.position]} took ${ksName}.</p><p class="small">Pick a keystone with games from the comparison below, or check back once more games are collected.</p></div>` + keystoneTable;
    bindBuild(); return;
  }

  const R = d.runes;
  const optimisedPrimary = [d.keystone, ...R.primaryRows.map((r) => r.best)].filter(Boolean);
  const subPair = (R.subPair || '').split(',').filter(Boolean).map(Number);
  const shardPick = R.shards.map((row) => row[0]?.id).filter(Boolean);

  const runeRows = R.primaryRows.map((row, i) => `<table class="cmp"><thead><tr><th>Row ${i + 1}</th><th>Games</th><th>Pick</th><th>Win rate</th><th class="hide-sm">KDA</th><th class="hide-sm">Dmg/min</th><th class="hide-sm">CS/min</th></tr></thead><tbody>
    ${row.options.map((o) => `<tr class="${o.id === row.best ? 'sel' : ''}"><td><div class="row">${runeImg(o.id, 'icon sm round')}${esc(S.runes[o.id]?.name)}</div></td>${o.games ? metricCells(o, d.baseline.winRate) : '<td class="muted" colspan="6">Not taken</td>'}</tr>`).join('')}</tbody></table>`).join('');

  const subTable = `<table class="cmp"><thead><tr><th>Secondary tree</th><th>Games</th><th>Pick</th><th>Win rate</th><th class="hide-sm">KDA</th><th class="hide-sm">Dmg/min</th><th class="hide-sm">CS/min</th></tr></thead><tbody>
    ${R.secondaryTrees.map((t) => `<tr class="${t.style === R.subTree ? 'sel' : ''}"><td><div class="row">${runeImg(t.style, 'icon sm')}${esc(S.styles[t.style]?.name)}</div></td>${metricCells({ ...t, cspm: undefined }, d.baseline.winRate)}</tr>`).join('')}</tbody></table>
    <table class="cmp"><thead><tr><th>Runes in ${esc(S.styles[R.subTree]?.name || '')}</th><th>Games</th><th>Pick</th><th>Win rate</th><th class="hide-sm">KDA</th><th class="hide-sm">Dmg/min</th><th class="hide-sm">CS/min</th></tr></thead><tbody>
    ${R.subRunes.map((o) => `<tr class="${subPair.includes(Number(o.key)) ? 'sel' : ''}"><td><div class="row">${runeImg(Number(o.key), 'icon sm round')}${esc(S.runes[o.key]?.name)}</div></td>${metricCells(o, d.baseline.winRate)}</tr>`).join('')}</tbody></table>`;

  const slotCard = (s, i) => `<div class="slot ${s.locked ? 'locked' : ''}">
    <div class="small muted">Item ${i + 1}${s.locked ? ' · locked' : ''}</div>
    <div class="items big">${itemImg(s.item)}</div>
    <div class="small"><b>${esc(S.items[s.item]?.name || s.item)}</b></div>
    <div class="small"><span class="num ${wrClass(s.winRate)}">${s.games ? pct(s.winRate) : '–'}</span> <span class="muted">${s.games} games</span></div>
    ${s.locked ? `<button class="btn small-btn" data-unlock="${i}">Unlock</button>` : `<button class="btn small-btn" data-lock="${i}" data-item="${s.item}">Lock</button>`}
    ${s.alts.length ? `<div class="alts"><div class="small muted">Swap for</div>${s.alts.map((a) => `<button class="alt" data-lock="${i}" data-item="${a.item}" title="${esc(S.items[a.item]?.name)}: ${pct(a.winRate)} in ${a.games} games">${itemImg(a.item)}<span class="small num ${wrClass(a.winRate)}">${pct(a.winRate, 0)}</span></button>`).join('')}</div>` : ''}
  </div>`;

  view.innerHTML = head + `
    <div class="panel" style="margin-bottom:16px">
      <div class="row wrap" style="justify-content:space-between;gap:12px;margin-bottom:12px"><h3>Keystone</h3>
        <div class="tabs"><a href="#" data-mode="winrate" class="${state.mode === 'winrate' ? 'on' : ''}">Highest win rate</a><a href="#" data-mode="popular" class="${state.mode === 'popular' ? 'on' : ''}">Most played</a></div></div>
      ${picker}
    </div>
    <div class="grid-2 plan">
      <div class="stack">
        <div class="panel"><h3>Optimised rune page</h3>
          <p class="small muted">${d.baseline.games} games with ${ksName} · ${pct(d.baseline.winRate)} win rate. Each row is picked separately${state.mode === 'winrate' ? ' (options under ' + d.minGames + ' games are skipped)' : ''}.</p>
          <div class="build-line"><div>${runePage(`${d.tree}:${optimisedPrimary.join(',')}|${R.subTree}:${subPair.join(',')}|${shardPick.join(',')}`)}</div></div>
          ${R.popularPage ? `<p class="small muted" style="margin-top:10px">Most played complete page (${R.popularPage.games} games, ${pct(R.popularPage.winRate)}):</p><div class="build-line">${runePage(R.popularPage.key)}</div>` : ''}
        </div>
        <div class="panel"><h3>Summoner spells</h3>${d.spells.map((s) => `<div class="build-line"><div class="row">${s.key.split('-').map((k) => spellImg(k, 'icon')).join('')}</div><div style="margin-left:auto;text-align:right" class="small"><span class="num ${wrClass(s.winRate)}">${pct(s.winRate)}</span><br><span class="muted">${s.games} games</span></div></div>`).join('')}</div>
        <div class="panel"><h3>Build totals</h3><p class="small muted">Core items plus top boots.</p>
          <p class="num" style="font-size:24px;color:var(--accent-soft)">${d.totals.gold.toLocaleString()} gold</p>
          <div class="totals">${d.totals.stats.map((s) => `<div class="row small" style="justify-content:space-between"><span>${esc(s.name.replace(' %', ''))}</span><b class="num">${s.value}${s.name.endsWith(' %') ? '%' : ''}</b></div>`).join('') || '<p class="small muted">No stat data.</p>'}</div></div>
      </div>
      <div class="stack">
        <div class="panel"><h3>Item path</h3>
          <p class="small muted">Each item is chosen from games that already had the items before it. Lock an item or swap in an alternative and the rest re-optimises around it.</p>
          ${d.items.length ? `<div class="slots">${d.items.map(slotCard).join('')}</div>` : '<p class="small muted">Not enough games with this keystone to build an item path yet.</p>'}
          ${d.items.length && d.items.length < 5 ? `<p class="small muted" style="margin-top:8px">Later items are situational: too few games reach item ${d.items.length + 1} with this exact path.</p>` : ''}
          <div class="row wrap" style="gap:8px;margin-top:10px">${fixed.some(Boolean) ? `<button class="btn" id="clear-locks">Clear locks</button>` : ''}${d.items.length ? `<a class="btn" href="${makerHash(planToBuild(Number(key), d))}">Edit this build in the build maker</a>` : ''}</div>
        </div>
        <div class="panel"><h3>Boots</h3>${d.boots.map((b) => `<div class="build-line"><div class="row"><div class="items">${itemImg(b.item)}</div><span class="small">${esc(S.items[b.item]?.name || '')}</span></div><div style="margin-left:auto;text-align:right" class="small"><span class="num ${wrClass(b.winRate)}">${pct(b.winRate)}</span><br><span class="muted">${b.games} games</span></div></div>`).join('') || '<p class="small muted">No data.</p>'}</div>
      </div>
    </div>
    <h2 style="margin:28px 0 12px">Rune comparisons</h2>
    ${keystoneTable}
    <div class="panel" style="overflow-x:auto"><h3>${ksName}: primary rows</h3><p class="small muted">Highlighted rows are in the optimised page. Win rate difference is against the ${ksName} average.</p>${runeRows}</div>
    <div class="panel" style="overflow-x:auto"><h3>Secondary runes</h3>${subTable}</div>
    <div class="panel"><h3>Stat shards</h3>${R.shards.map((row, i) => `<div class="build-line"><span class="small muted" style="width:70px">${['Offense', 'Flex', 'Defense'][i]}</span>${row.map((o) => `<span class="pill" style="${o.id === row[0]?.id ? 'color:var(--text);border:1px solid var(--accent)' : ''}">${esc(S.runes[o.id]?.name || o.id)} · ${pct(o.winRate, 0)} · ${o.games}</span>`).join(' ')}</div>`).join('')}</div>`;
  bindBuild();

  function bindBuild() {
    view.querySelectorAll('[data-ks]').forEach((el) => el.onclick = (e) => { e.preventDefault(); go({ ks: el.dataset.ks, fixed: [] }); });
    view.querySelectorAll('[data-mode]').forEach((el) => el.onclick = (e) => { e.preventDefault(); go({ mode: el.dataset.mode }); });
    view.querySelectorAll('[data-lock]').forEach((el) => el.onclick = () => { const f = [...state.fixed]; f[Number(el.dataset.lock)] = el.dataset.item; go({ fixed: f }); });
    view.querySelectorAll('[data-unlock]').forEach((el) => el.onclick = () => { const f = [...state.fixed]; f[Number(el.dataset.unlock)] = ''; go({ fixed: f }); });
    const cl = document.getElementById('clear-locks'); if (cl) cl.onclick = () => go({ fixed: [] });
  }
}

// ---------- router ----------
async function route() {
  const [pathPart, qs] = location.hash.replace(/^#\/?/, '').split('?');
  const parts = pathPart.split('/').map(decodeURIComponent);
  const [page, a, b] = parts;
  const q = new URLSearchParams(qs || '');
  document.querySelectorAll('.nav a').forEach((n) => n.classList.toggle('on', n.dataset.nav === page || (page === 'champion' && n.dataset.nav === 'champions')));
  try {
    await refreshStatus();
    if (page === 'player' && a && b) await pagePlayer(a, b);
    else if (page === 'live' && a && b) await pageLive(a, b);
    else if (page === 'live') await pageLiveEntry();
    else if (page === 'tierlist') await pageTierList(a || 'ALL');
    else if (page === 'champions') await pageChampions();
    else if (page === 'champion' && a) await pageChampion(a, b);
    else if (page === 'build') await pageBuild(a, b, q);
    else if (page === 'maker' && a) await pageMaker(a, q);
    else if (page === 'maker') await pageMakerHome();
    else if (page === 'settings') await pageSettings();
    else await pageHome();
  } catch (e) { fail(e); }
  view.focus({ preventScroll: true });
}

(async () => {
  try { S = await api('/static'); }
  catch (e) { view.innerHTML = `<div class="panel empty error">${esc(e.message)}</div>`; return; }
  // installable app (Chrome, Edge, Android; on iPhone use Share > Add to Home Screen)
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  let installPrompt = null;
  const installBtn = document.getElementById('install');
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); installPrompt = e; installBtn.hidden = false; });
  installBtn.onclick = async () => { if (!installPrompt) return; installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; installBtn.hidden = true; };
  window.addEventListener('appinstalled', () => { installBtn.hidden = true; });
  const eloSel = document.getElementById('elo');
  eloSel.value = ELO;
  eloSel.onchange = () => { ELO = eloSel.value; try { localStorage.setItem('riftlens.elo', ELO); } catch {} route(); };
  window.addEventListener('hashchange', () => { window.scrollTo(0, 0); route(); });
  route();
})();
