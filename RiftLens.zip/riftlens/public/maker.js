// RiftLens build maker: put a build together yourself (any items, runes, shards and spells),
// see its stats at any level, check how those picks have done in collected ranked games,
// compare it with another build, and save it on this PC.
// Uses helpers and state from app.js (S, view, api, esc, pct, champ, images...).

const SHARD_ROWS = [[5008, 5005, 5007], [5008, 5010, 5001], [5011, 5013, 5001]];
const SHARD_LABEL = ['Offense', 'Flex', 'Defense'];
const POS_LIST = ['TOP', 'JUNGLE', 'MIDDLE', 'BOTTOM', 'UTILITY'];
const STAT_FILTERS = {
  'Attack damage': ['Attack Damage'], 'Ability power': ['Ability Power'], 'Attack speed': ['Attack Speed'],
  Crit: ['Critical Strike Chance'], Health: ['Health'], Armor: ['Armor'], 'Magic resist': ['Magic Resist'],
  'Ability haste': ['Ability Haste'], Lethality: ['Lethality', 'Armor Penetration'], Mana: ['Mana'], 'Move speed': ['Move Speed'],
};

function blankBuild(key) {
  return {
    id: '', name: '', champion: Number(key), position: '', items: [0, 0, 0, 0, 0, 0],
    runes: { primary: 0, picks: [0, 0, 0, 0], secondary: 0, subPicks: [], shards: [5008, 5008, 5011] },
    spells: [], notes: '',
  };
}

// Normalise anything (saved file, URL, planner result) into a full build object.
function normBuild(b) {
  const out = blankBuild(b.champion);
  out.id = b.id || ''; out.name = b.name || ''; out.notes = b.notes || '';
  out.position = POS_LIST.includes(b.position) ? b.position : '';
  for (let i = 0; i < 6; i++) out.items[i] = Number(b.items?.[i]) || 0;
  const r = b.runes || {};
  out.runes.primary = Number(r.primary) || 0;
  out.runes.picks = [0, 1, 2, 3].map((i) => Number(r.picks?.[i]) || 0);
  out.runes.secondary = Number(r.secondary) || 0;
  out.runes.subPicks = (r.subPicks || []).map(Number).filter(Boolean).slice(0, 2);
  if (r.shards?.length === 3) out.runes.shards = r.shards.map(Number);
  out.spells = (b.spells || []).map(Number).filter(Boolean).slice(0, 2);
  return out;
}

function makerHash(b) {
  const p = new URLSearchParams();
  if (b.id) p.set('id', b.id);
  if (b.name) p.set('n', b.name);
  if (b.position) p.set('pos', b.position);
  if (b.items.some(Boolean)) p.set('i', b.items.join(','));
  const r = b.runes;
  if (r.primary) p.set('r', [r.primary, r.picks.join('.'), r.secondary, r.subPicks.join('.'), r.shards.join('.')].join('_'));
  if (b.spells.length) p.set('s', b.spells.join(','));
  const s = p.toString();
  return `#/maker/${b.champion}${s ? '?' + s : ''}`;
}

function buildFromQuery(key, q) {
  const list = (x) => (x || '').split(/[.,]/).filter(Boolean).map(Number);
  const [p, pk, s, sp, sh] = (q.get('r') || '').split('_');
  return normBuild({
    champion: key, id: q.get('id'), name: q.get('n'), position: q.get('pos'), items: list(q.get('i')),
    runes: { primary: p, picks: list(pk), secondary: s, subPicks: list(sp), shards: list(sh) }, spells: list(q.get('s')),
  });
}

// Turn a build planner result into an editable build.
function planToBuild(key, d, keep = {}) {
  const R = d.runes;
  const items = d.items.map((s) => s.item).slice(0, 5);
  if (d.boots?.[0]) items.splice(Math.min(1, items.length), 0, d.boots[0].item);
  return normBuild({
    ...keep, champion: key, position: keep.position || d.position, items,
    runes: {
      primary: d.tree, picks: [d.keystone, ...R.primaryRows.map((r) => r.best || 0)],
      secondary: R.subTree, subPicks: (R.subPair || '').split(',').map(Number).filter(Boolean),
      shards: R.shards.map((row, i) => row[0]?.id || [5008, 5008, 5011][i]),
    },
    spells: (d.spells?.[0]?.key || '').split('-').map(Number),
  });
}

// Turn a ranked-builds row (items + most common rune page + spells) into an editable build.
function rowToBuild(key, position, row) {
  const [prim, sub, shards] = (row.runes || '0:|0:|').split('|');
  const [ps, pr] = prim.split(':'); const [ss, sr] = sub.split(':');
  const items = [...row.items];
  if (row.boots) items.splice(Math.min(1, items.length), 0, row.boots);
  return normBuild({
    champion: key, position, items,
    runes: { primary: ps, picks: (pr || '').split(','), secondary: ss, subPicks: (sr || '').split(','), shards: (shards || '').split(',') },
    spells: (row.spells || '').split('-'),
  });
}

// ---------- stats ----------
function itemTotals(items) {
  const t = {}; let gold = 0;
  for (const id of items) {
    const it = S.items[id]; if (!it) continue;
    gold += it.gold;
    for (const [v, isPct, name] of it.stats || []) { const k = name + (isPct ? ' %' : ''); t[k] = (t[k] || 0) + v; }
  }
  return { t, gold };
}

// Champion base stats at a level + item stats + stat shards. Passives, rune effects and
// percentage-of-stat item effects aren't modelled.
function buildStats(b, lvl) {
  const c = champ(b.champion); const cs = c.stats || {};
  const g = (lvl - 1) * (0.7025 + 0.0175 * (lvl - 1)); // Riot's per-level growth curve
  const { t, gold } = itemTotals(b.items.filter(Boolean));
  const used = new Set();
  const get = (k) => { used.add(k); return t[k] || 0; };
  const sh = b.runes.shards || [];
  const n = (id) => sh.filter((x) => x === id).length;
  const itemAD = get('Attack Damage'), itemAP = get('Ability Power');
  const adaptiveAP = itemAP > itemAD || (itemAP === itemAD && (c.tags || []).includes('Mage'));
  const adaptive = n(5008) * 9;
  const hp = (cs.hp || 0) + (cs.hpperlevel || 0) * g + get('Health') + n(5011) * 65 + n(5001) * (10 + (170 * (lvl - 1)) / 17);
  const armor = (cs.armor || 0) + (cs.armorperlevel || 0) * g + get('Armor');
  const mr = (cs.spellblock || 0) + (cs.spellblockperlevel || 0) * g + get('Magic Resist');
  const ah = get('Ability Haste') + n(5007) * 8;
  const asBonus = (cs.attackspeedperlevel || 0) * g + get('Attack Speed %') + n(5005) * 10;
  const rows = [
    { k: 'hp', label: 'Health', v: hp },
    ...(c.partype === 'Mana' ? [{ k: 'mana', label: 'Mana', v: (cs.mp || 0) + (cs.mpperlevel || 0) * g + get('Mana') }] : []),
    { k: 'ad', label: 'Attack damage', v: (cs.attackdamage || 0) + (cs.attackdamageperlevel || 0) * g + itemAD + (adaptiveAP ? 0 : adaptive * 0.6) },
    { k: 'ap', label: 'Ability power', v: itemAP + (adaptiveAP ? adaptive : 0) },
    { k: 'armor', label: 'Armor', v: armor },
    { k: 'mr', label: 'Magic resist', v: mr },
    { k: 'as', label: 'Attack speed', v: Math.min(2.5, (cs.attackspeed || 0.625) * (1 + asBonus / 100)), dp: 3 },
    { k: 'crit', label: 'Crit chance', v: Math.min(100, get('Critical Strike Chance %')), unit: '%' },
    { k: 'ah', label: 'Ability haste', v: ah, note: ah ? `${Math.round((ah / (ah + 100)) * 100)}% shorter cooldowns` : '' },
    { k: 'ms', label: 'Move speed', v: ((cs.movespeed || 0) + get('Move Speed')) * (1 + (get('Move Speed %') + n(5010) * 2) / 100) },
    { k: 'leth', label: 'Lethality', v: get('Lethality') },
    { k: 'apen', label: 'Armor pen', v: get('Armor Penetration %'), unit: '%' },
    { k: 'mpen', label: 'Magic pen', v: get('Magic Penetration') },
    { k: 'mpenp', label: 'Magic pen %', v: get('Magic Penetration %'), unit: '%' },
    { k: 'ls', label: 'Life steal', v: get('Life Steal %'), unit: '%' },
    { k: 'ov', label: 'Omnivamp', v: get('Omnivamp %'), unit: '%' },
    { k: 'hsp', label: 'Heal & shield power', v: get('Heal and Shield Power %'), unit: '%' },
    { k: 'ten', label: 'Tenacity', v: get('Tenacity %') + n(5013) * 15, unit: '%' },
    { k: 'ehpp', label: 'Effective HP vs physical', v: hp * (1 + armor / 100), group: 'derived' },
    { k: 'ehpm', label: 'Effective HP vs magic', v: hp * (1 + mr / 100), group: 'derived' },
    { k: 'range', label: 'Attack range', v: cs.attackrange || 0, group: 'derived' },
  ];
  for (const [k, v] of Object.entries(t)) if (!used.has(k)) rows.push({ k: 'x:' + k, label: k.replace(' %', ''), v, unit: k.endsWith(' %') ? '%' : '' });
  return { rows, gold, adaptive: adaptive ? (adaptiveAP ? `${adaptive} AP` : `${(adaptive * 0.6).toFixed(1)} AD`) : '' };
}

const fmtStat = (r) => (r.dp ? r.v.toFixed(r.dp) : Math.round(r.v).toLocaleString()) + (r.unit || '');

// ---------- where saved builds live ----------
// On your PC they're saved in RiftLens's data folder; online, in the visitor's own browser.
const buildStore = {
  async list() { return ST.hosted ? local.get('builds', []) : api('/builds'); },
  async save(b) {
    if (!ST.hosted) return api('/builds', { method: 'POST', body: JSON.stringify(b) });
    const all = local.get('builds', []);
    const now = Date.now();
    const clean = { ...normBuild(b), name: String(b.name || '').slice(0, 60) || `${champ(b.champion).name} build`, notes: String(b.notes || '').slice(0, 1000) };
    let rec = b.id && all.find((x) => x.id === b.id);
    if (rec) Object.assign(rec, clean, { id: rec.id, updated: now });
    else { rec = { ...clean, id: newId(), created: now, updated: now }; all.push(rec); }
    if (!local.set('builds', all)) throw new Error("Couldn't save: this browser is blocking storage for this site.");
    return rec;
  },
  async remove(id) {
    if (!ST.hosted) return api('/builds/' + id, { method: 'DELETE' });
    local.set('builds', local.get('builds', []).filter((x) => x.id !== id));
  },
};
const newId = () => (crypto.randomUUID ? crypto.randomUUID() : 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10));

// ---------- saved builds list + champion picker ----------
async function pageMakerHome() {
  loading();
  const saved = await buildStore.list();
  const list = Object.values(S.champions).sort((a, b) => a.name.localeCompare(b.name));
  view.innerHTML = `<h1 style="margin-bottom:6px">Build maker</h1>
    <p class="muted" style="margin-bottom:16px">Make your own build: pick any items, runes, shards and summoner spells, see the stats at every level, and check how those picks have done in ranked games at the rank you pick at the top. ${ST.hosted ? 'Builds are saved in this browser.' : 'Builds are saved on this PC.'}</p>
    ${saved.length ? `<div class="panel" style="margin-bottom:16px"><h3>Your builds</h3><div class="saved-list">${saved.slice().sort((a, b) => b.updated - a.updated).map(savedCard).join('')}</div></div>` : ''}
    <h3 style="margin-bottom:10px">New build</h3>
    <input id="cf" placeholder="Filter champions" aria-label="Filter champions" class="field" style="margin-bottom:16px">
    <div class="champ-grid">${list.map((c) => `<a href="#/maker/${c.key}" data-n="${esc(c.name.toLowerCase())}"><img src="${cdn('champion/' + c.id + '.png')}" alt="" loading="lazy">${esc(c.name)}</a>`).join('')}</div>`;
  const f = document.getElementById('cf');
  f.oninput = () => view.querySelectorAll('.champ-grid a').forEach((a) => { a.hidden = !a.dataset.n.includes(f.value.toLowerCase()); });
  view.querySelectorAll('[data-del]').forEach((el) => el.onclick = async (e) => {
    e.preventDefault();
    if (el.dataset.armed !== '1') { el.dataset.armed = '1'; el.textContent = 'Click again to delete'; return; }
    await buildStore.remove(el.dataset.del);
    pageMakerHome();
  });
}

function savedCard(b) {
  const nb = normBuild(b);
  return `<div class="saved">
    <a href="#/maker/${Number(b.champion)}?id=${encodeURIComponent(b.id)}" class="row" style="color:var(--text)">${champImg(b.champion, 'icon')}
      <div style="min-width:0"><b>${esc(b.name)}</b><div class="small muted">${esc(champ(b.champion).name)}${b.position ? ' · ' + POS[b.position] : ''} · ${ago(b.updated)}</div></div></a>
    <div class="row" style="gap:6px;flex-wrap:wrap">${nb.runes.picks[0] ? runeImg(nb.runes.picks[0], 'icon sm round') : ''}<div class="items">${nb.items.filter(Boolean).map(itemImg).join('')}</div></div>
    <div class="row" style="gap:6px"><a class="btn small-btn" href="#/maker/${Number(b.champion)}?id=${encodeURIComponent(b.id)}">Open</a><button class="btn small-btn danger" data-del="${esc(b.id)}">Delete</button></div>
  </div>`;
}

// ---------- the editor ----------
async function pageMaker(key, q) {
  if (!S.champions[key]) return pageMakerHome();
  loading();
  const [saved, champData] = await Promise.all([buildStore.list(), api(`/champion/${key}?elo=${ELO}`).catch(() => null)]);
  let B;
  const fromSaved = q.get('id') && saved.find((x) => x.id === q.get('id'));
  if (fromSaved && !q.get('i') && !q.get('r')) B = normBuild(fromSaved);
  else B = buildFromQuery(key, q);
  if (q.get('id') && !fromSaved) B.id = '';
  const c = champ(key);
  const ui = { slot: B.items.findIndex((x) => !x), filter: 'legendary', stat: '', search: '', level: 18, compare: '', compareBuild: null, record: null, dirty: false, msg: '' };
  if (ui.slot < 0) ui.slot = 0;
  const popular = new Set([...(champData?.items || []), ...(champData?.boots || [])].map((x) => Number(x.key)));

  // shop list: one entry per item name, sorted legendary > boots > epic > basic
  const order = { legendary: 0, boots: 1, epic: 2, basic: 3, other: 4 };
  const seen = new Set();
  const shop = Object.entries(S.items)
    .filter(([, it]) => (it.shop ?? true) && it.gold > 0)
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .filter(([, it]) => (seen.has(it.name) ? false : seen.add(it.name)))
    .map(([id, it]) => ({ id: Number(id), ...it, tier: it.tier || (it.legendary ? 'legendary' : it.boots ? 'boots' : 'other') }))
    .sort((a, b) => order[a.tier] - order[b.tier] || b.gold - a.gold || a.name.localeCompare(b.name));
  const styleIds = Object.keys(S.styles).filter((id) => S.styles[id].slots).map(Number);
  const riftSpells = Object.entries(S.spells).filter(([, s]) => s.rift !== false).map(([k, s]) => ({ key: Number(k), ...s }))
    .sort((a, b) => a.name.localeCompare(b.name));

  view.innerHTML = `
    <div class="row wrap" style="gap:16px;margin-bottom:16px">
      <a href="#/maker" title="Back to your builds">${champImg(key, 'icon lg')}</a>
      <div style="flex:1;min-width:220px">
        <input id="mk-name" class="field title-field" maxlength="60" aria-label="Build name" placeholder="${esc(c.name)} build" value="${esc(B.name)}">
        <div class="small muted" id="mk-sub"></div>
      </div>
      <div class="row wrap" style="gap:8px" id="mk-actions"></div>
    </div>
    <div class="panel" style="margin-bottom:16px"><div class="row wrap" style="justify-content:space-between;gap:10px">
      <div><div class="small muted" style="margin-bottom:4px">Role (used for the win-rate check)</div><nav class="tabs" id="mk-roles"></nav></div>
      <div class="row wrap" style="gap:8px"><button class="btn" data-act="fill">Start from best-record build</button><button class="btn" data-act="clear">Clear</button></div>
    </div></div>
    <div class="maker">
      <div class="stack">
        <div class="panel"><h3>Items</h3><p class="small muted">Click a slot, then pick an item below. Use the arrows to change the order you buy them.</p><div id="mk-slots" class="mk-slots"></div>
          <div class="picker-head">
            <input id="mk-search" class="field" placeholder="Search items" aria-label="Search items">
            <div class="chips" id="mk-tiers"></div>
          </div>
          <div class="chips" id="mk-stats" style="margin-bottom:10px"></div>
          <div id="mk-picker" class="picker"></div>
        </div>
        <div class="panel"><h3>Runes</h3><div id="mk-runes"></div></div>
        <div class="panel"><h3>Summoner spells</h3><div id="mk-spells" class="spell-pick"></div></div>
        <div class="panel"><h3>Notes</h3><textarea id="mk-notes" class="field" rows="3" maxlength="1000" placeholder="When to go this build, matchups, power spikes..." style="width:100%">${esc(B.notes)}</textarea></div>
      </div>
      <div class="stack mk-side">
        <div class="panel"><div class="row" style="justify-content:space-between"><h3>Stats</h3><span class="num" id="mk-gold"></span></div>
          <label class="small muted" for="mk-level">Level <b id="mk-lvl-out" class="num" style="color:var(--text)">18</b></label>
          <input type="range" id="mk-level" min="1" max="18" value="18" style="width:100%">
          <label class="small muted" for="mk-compare" style="display:block;margin-top:8px">Compare with</label>
          <select id="mk-compare" class="field" style="width:100%"></select>
          <div id="mk-stattable" style="margin-top:10px"></div>
        </div>
        <div class="panel"><h3>How these picks have done</h3><div id="mk-record"><p class="small muted">Pick some items or runes.</p></div></div>
      </div>
    </div>`;

  const $ = (id) => document.getElementById(id);
  const rowOf = (id) => S.runes[id]?.row;

  function changed() {
    ui.dirty = true; ui.msg = '';
    history.replaceState(null, '', makerHash(B));
    paint();
    scheduleCheck();
  }

  // ---- painters ----
  function paintHead() {
    const st = buildStats(B, ui.level);
    $('mk-sub').textContent = `${c.name} · ${B.items.filter(Boolean).length}/6 items · ${st.gold.toLocaleString()} gold`;
    $('mk-actions').innerHTML = `
      ${ui.msg ? `<span class="small ${ui.msgErr ? 'error' : 'good'}">${esc(ui.msg)}</span>` : ui.dirty && B.id ? '<span class="small muted">Unsaved changes</span>' : ''}
      <button class="btn primary" data-act="save">${B.id ? 'Save' : 'Save build'}</button>
      ${B.id ? '<button class="btn" data-act="saveas">Save as new</button>' : ''}
      <a class="btn" href="${buildHash(key, B.position, { ks: B.runes.picks[0] || '', fixed: B.items.filter((x) => S.items[x]?.legendary).slice(0, 5) })}" title="Open the build planner with your keystone and items locked">Optimise around this</a>`;
    $('mk-roles').innerHTML = [['', 'Auto'], ...POS_LIST.map((p) => [p, POS[p]])].map(([p, label]) => {
      const games = p && ui.record?.positionCounts?.[p];
      return `<a href="#" data-role="${p}" class="${B.position === p ? 'on' : ''}">${label}${games ? ` <span class="muted small">${games}</span>` : ''}</a>`;
    }).join('');
  }

  function paintSlots() {
    $('mk-slots').innerHTML = B.items.map((id, i) => {
      const it = S.items[id];
      return `<div class="mk-slot ${ui.slot === i ? 'target' : ''}" data-act="slot" data-i="${i}" tabindex="0" role="button" aria-label="Item slot ${i + 1}${it ? ': ' + esc(it.name) : ', empty'}">
        <div class="items big">${id ? itemImg(id) : '<span class="empty-slot">+</span>'}</div>
        <div class="small mk-slot-name">${it ? esc(it.name) : `<span class="muted">Slot ${i + 1}</span>`}</div>
        ${id ? `<div class="row mk-slot-tools"><button class="icon-btn" data-act="left" data-i="${i}" aria-label="Move earlier" ${i === 0 ? 'disabled' : ''}>‹</button><button class="icon-btn" data-act="remove" data-i="${i}" aria-label="Remove">×</button><button class="icon-btn" data-act="right" data-i="${i}" aria-label="Move later" ${i === 5 ? 'disabled' : ''}>›</button></div>` : ''}
      </div>`;
    }).join('');
  }

  function paintFilters() {
    const tiers = [['legendary', 'Legendary'], ['boots', 'Boots'], ['parts', 'Components'], ['all', 'All'], ...(popular.size ? [['popular', `Popular on ${c.name}`]] : [])];
    $('mk-tiers').innerHTML = tiers.map(([k, l]) => `<button class="chip ${ui.filter === k ? 'on' : ''}" data-act="tier" data-k="${k}">${esc(l)}</button>`).join('');
    $('mk-stats').innerHTML = Object.keys(STAT_FILTERS).map((k) => `<button class="chip ${ui.stat === k ? 'on' : ''}" data-act="stat" data-k="${esc(k)}">${esc(k)}</button>`).join('');
  }

  function paintPicker() {
    const q = ui.search.trim().toLowerCase();
    const inBuild = new Set(B.items.filter(Boolean));
    const list = shop.filter((it) => {
      if (q) { if (!it.name.toLowerCase().includes(q)) return false; }
      else if (ui.filter === 'parts') { if (!['epic', 'basic'].includes(it.tier)) return false; }
      else if (ui.filter === 'popular') { if (!popular.has(it.id)) return false; }
      else if (ui.filter !== 'all' && it.tier !== ui.filter) return false;
      if (ui.stat && !(it.stats || []).some(([, , n]) => STAT_FILTERS[ui.stat].includes(n))) return false;
      return true;
    });
    $('mk-picker').innerHTML = list.map((it) => {
      const unique = (it.legendary || it.boots) && inBuild.has(it.id);
      const tip = `${it.name} · ${it.gold} gold${(it.stats || []).length ? '\n' + it.stats.map(([v, p, n]) => `${v}${p ? '%' : ''} ${n}`).join('\n') : ''}`;
      return `<button class="pk" data-act="pick" data-id="${it.id}" title="${esc(tip)}" ${unique ? 'disabled' : ''}>
        <img src="${cdn('item/' + it.id + '.png')}" alt="" loading="lazy"><span class="pk-name">${esc(it.name)}</span><span class="pk-gold num">${it.gold}${unique ? ' · in build' : ''}</span></button>`;
    }).join('') || '<p class="small muted">No items match.</p>';
  }

  function runeBtn(id, on, extra = '') {
    const r = S.runes[id];
    return `<button class="rn ${on ? 'on' : ''} ${r?.keystone ? 'ksb' : ''}" data-act="${extra}" data-id="${id}" title="${esc(r?.name || '')}${r?.desc ? '\n' + esc(r.desc) : ''}" aria-pressed="${on}">${runeImg(id, r?.keystone ? 'icon' : 'icon sm round')}</button>`;
  }

  function paintRunes() {
    const R = B.runes;
    const tree = (sel, act, skip) => `<div class="row wrap" style="gap:6px">${styleIds.filter((s) => s !== skip).map((s) =>
      `<button class="rn tree ${sel === s ? 'on' : ''}" data-act="${act}" data-id="${s}" title="${esc(S.styles[s].name)}" aria-pressed="${sel === s}">${runeImg(s, 'icon sm')}<span class="small">${esc(S.styles[s].name)}</span></button>`).join('')}</div>`;
    let html = `<div class="small muted" style="margin-bottom:6px">Primary tree</div>${tree(R.primary, 'ptree')}`;
    if (R.primary) {
      const slots = S.styles[R.primary].slots;
      html += `<div class="rune-rows">${slots.map((ids, row) => `<div class="rune-row ${row === 0 ? 'ks-row' : ''}">${ids.map((id) => runeBtn(id, R.picks[row] === id, 'prune')).join('')}<span class="small muted rune-pick">${R.picks[row] ? esc(S.runes[R.picks[row]]?.name) : row === 0 ? 'Pick a keystone' : 'Pick one'}</span></div>`).join('')}</div>`;
      html += `<div class="small muted" style="margin:14px 0 6px">Secondary tree <span class="muted">(two runes from different rows)</span></div>${tree(R.secondary, 'stree', R.primary)}`;
      if (R.secondary) {
        const slots2 = S.styles[R.secondary].slots.slice(1);
        html += `<div class="rune-rows">${slots2.map((ids) => `<div class="rune-row">${ids.map((id) => runeBtn(id, R.subPicks.includes(id), 'srune')).join('')}</div>`).join('')}</div>`;
      }
    }
    html += `<div class="small muted" style="margin:14px 0 6px">Stat shards</div>${SHARD_ROWS.map((ids, row) => `<div class="row" style="gap:6px;margin-bottom:6px"><span class="small muted" style="width:62px">${SHARD_LABEL[row]}</span>${ids.map((id) =>
      `<button class="chip ${R.shards[row] === id ? 'on' : ''}" data-act="shard" data-row="${row}" data-id="${id}">${esc(S.runes[id]?.name || id)}</button>`).join('')}</div>`).join('')}`;
    $('mk-runes').innerHTML = html;
  }

  function paintSpells() {
    $('mk-spells').innerHTML = riftSpells.map((s) => `<button class="rn sp ${B.spells.includes(s.key) ? 'on' : ''}" data-act="spell" data-id="${s.key}" title="${esc(s.name)}" aria-pressed="${B.spells.includes(s.key)}">${spellImg(s.key, 'icon')}<span class="small">${esc(s.name)}</span></button>`).join('');
  }

  function paintCompareOptions() {
    const mine = saved.filter((x) => x.champion === B.champion && x.id !== B.id);
    $('mk-compare').innerHTML = `<option value="">Nothing</option><option value="naked" ${ui.compare === 'naked' ? 'selected' : ''}>${esc(c.name)} with no items</option><option value="plan" ${ui.compare === 'plan' ? 'selected' : ''}>Best-record build (build planner)</option>${mine.map((x) => `<option value="${x.id}" ${ui.compare === x.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}`;
  }

  function paintStats() {
    const a = buildStats(B, ui.level);
    const cmp = ui.compareBuild ? buildStats(ui.compareBuild, ui.level) : null;
    const cm = cmp ? Object.fromEntries(cmp.rows.map((r) => [r.k, r])) : {};
    const keys = new Set(a.rows.map((r) => r.k));
    const rows = [...a.rows, ...(cmp ? cmp.rows.filter((r) => !keys.has(r.k)).map((r) => ({ ...r, v: 0 })) : [])]
      .filter((r) => r.v || cm[r.k]?.v || ['hp', 'ad', 'armor', 'mr', 'as', 'ms'].includes(r.k));
    const line = (r) => {
      const o = cm[r.k];
      const d = o ? r.v - o.v : 0;
      const dTxt = !o || Math.abs(d) < (r.dp ? 0.0005 : 0.5) ? '' : `<span class="${d > 0 ? 'good' : 'loss'}">${d > 0 ? '+' : '−'}${fmtStat({ ...r, v: Math.abs(d) })}</span>`;
      return `<tr><td>${esc(r.label)}${r.note ? `<div class="small muted">${esc(r.note)}</div>` : ''}</td><td class="num">${fmtStat(r)}</td>${cmp ? `<td class="num muted">${o ? fmtStat(o) : '–'}</td><td class="num">${dTxt}</td>` : ''}</tr>`;
    };
    const main = rows.filter((r) => r.group !== 'derived'), derived = rows.filter((r) => r.group === 'derived');
    const goldD = cmp ? a.gold - cmp.gold : 0;
    $('mk-gold').innerHTML = `${a.gold.toLocaleString()} gold${cmp && goldD ? ` <span class="small muted">(${goldD > 0 ? '+' : '−'}${Math.abs(goldD).toLocaleString()})</span>` : ''}`;
    $('mk-stattable').innerHTML = `<table class="stat-table"><thead><tr><th>Stat</th><th>This build</th>${cmp ? '<th>Other</th><th>Diff</th>' : ''}</tr></thead>
      <tbody>${main.map(line).join('')}<tr class="sep"><td colspan="${cmp ? 4 : 2}"></td></tr>${derived.map(line).join('')}</tbody></table>
      <p class="small muted" style="margin-top:8px">Base stats at level ${ui.level} plus items and shards${a.adaptive ? ` (adaptive shards give ${a.adaptive})` : ''}. Item passives, rune effects and abilities aren't included.</p>`;
    $('mk-lvl-out').textContent = ui.level;
  }

  function paintRecord() {
    const d = ui.record;
    if (!d) return;
    const el = $('mk-record');
    const posName = POS[d.position] || 'any role';
    if (!d.games) { el.innerHTML = `<p class="small muted">No collected games on ${esc(c.name)} ${d.position ? POS[d.position] : ''} for ${esc(eloLabel())} yet. This fills in as RiftLens collects games.</p>`; return; }
    const wr = (m) => (m && m.games ? `<span class="num ${wrClass(m.winRate)}">${pct(m.winRate)}</span> <span class="muted">${m.games} game${m.games === 1 ? '' : 's'}</span>` : '<span class="muted">not played</span>');
    const line = (icon, label, m) => `<div class="rec-line">${icon}<span class="rec-label">${label}</span><span class="small rec-val">${wr(m)}</span></div>`;
    let html = `<p class="small muted">${d.games} games of ${esc(c.name)} ${posName}, ${esc(eloLabel())} (${pct(d.baseline.winRate)} average win rate)${Array.isArray(d.patches) ? `, patch ${d.patches.join(' + ')}` : ''}.</p>`;
    if (d.together) {
      html += line('', d.together.count === 1 ? 'This completed item' : `These ${d.together.count} completed items together`, d.together);
      if (!d.together.games && d.core && d.core.count < d.together.count) html += line('', `Your first ${d.core.count} item${d.core.count === 1 ? '' : 's'}`, d.core);
    }
    if (d.items?.length) html += `<div class="rec-group">${d.items.map((x) => x.tracked === false
      ? `<div class="rec-line"><div class="items">${itemImg(x.item)}</div><span class="rec-label small">${esc(S.items[x.item]?.name || '')}</span><span class="small muted rec-val">not tracked</span></div>`
      : line(`<div class="items">${itemImg(x.item)}</div>`, `<span class="small">${esc(S.items[x.item]?.name || '')}</span>`, x)).join('')}</div>`;
    if (d.keystone) {
      html += `<div class="rec-group">${line(runeImg(d.keystone.id, 'icon sm round'), `<span class="small">${esc(S.runes[d.keystone.id]?.name || '')}</span>`, d.keystone)}`;
      html += (d.runes || []).map((r) => line(runeImg(r.id, 'icon sm round'), `<span class="small">${esc(S.runes[r.id]?.name || '')} <span class="muted">with this keystone</span></span>`, r)).join('');
      html += line('', '<span class="small">This exact rune page</span>', d.page) + '</div>';
    }
    if (d.spells) html += `<div class="rec-group">${line(`<div class="row" style="gap:3px">${B.spells.map((k) => spellImg(k, 'icon sm')).join('')}</div>`, '<span class="small">These summoner spells</span>', d.spells)}</div>`;
    html += '<p class="small muted" style="margin-top:8px">Fewer than about 20 games is too small a sample to read much into. Components aren\'t tracked because games only record finished inventories.</p>';
    el.innerHTML = html;
  }

  function paint() { paintHead(); paintSlots(); paintFilters(); paintPicker(); paintRunes(); paintSpells(); paintStats(); }

  // ---- win-rate check (debounced) ----
  let checkTimer = null, checkSeq = 0;
  function scheduleCheck() {
    clearTimeout(checkTimer);
    checkTimer = setTimeout(async () => {
      const seq = ++checkSeq;
      try {
        const d = await api(`/check/${key}`, { method: 'POST', body: JSON.stringify({ ...B, elo: ELO }) });
        if (seq !== checkSeq) return;
        ui.record = d;
        ui.record.positionCounts = Object.fromEntries((champData?.positions || []).map((p) => [p.position, p.games]));
        paintRecord(); paintHead();
      } catch (e) { $('mk-record').innerHTML = `<p class="small error">${esc(e.message)}</p>`; }
    }, 250);
  }

  async function loadCompare() {
    const v = ui.compare;
    ui.compareBuild = null;
    if (v === 'naked') ui.compareBuild = normBuild({ champion: key, runes: { shards: [0, 0, 0] } });
    else if (v === 'plan') {
      try {
        const d = await api(`/planner/${key}?` + new URLSearchParams({ position: B.position || '', elo: ELO }));
        if (d.empty || d.noKeystoneData) { ui.msg = 'No collected games to build a comparison from yet.'; ui.msgErr = true; }
        else ui.compareBuild = planToBuild(key, d);
      } catch (e) { ui.msg = e.message; ui.msgErr = true; }
    } else if (v) { const s = saved.find((x) => x.id === v); if (s) ui.compareBuild = normBuild(s); }
    paintHead(); paintStats();
  }

  async function save(asNew) {
    B.name = $('mk-name').value.trim() || `${c.name} build`;
    $('mk-name').value = B.name;
    B.notes = $('mk-notes').value;
    try {
      const res = await buildStore.save({ ...B, id: asNew ? '' : B.id });
      B.id = res.id;
      const i = saved.findIndex((x) => x.id === res.id);
      if (i >= 0) saved[i] = res; else saved.push(res);
      ui.dirty = false; ui.msg = 'Saved'; ui.msgErr = false;
      history.replaceState(null, '', makerHash(B));
      paintCompareOptions(); paintHead();
    } catch (e) { ui.msg = e.message; ui.msgErr = true; paintHead(); }
  }

  async function fillFromPlan() {
    try {
      const d = await api(`/planner/${key}?` + new URLSearchParams({ position: B.position || '', keystone: B.runes.picks[0] || '', elo: ELO }));
      if (d.empty) { ui.msg = `No games on ${c.name} collected yet for ${eloLabel()}.`; ui.msgErr = true; return paintHead(); }
      if (d.noKeystoneData) { ui.msg = 'No collected games with that keystone yet. Clear the keystone and try again.'; ui.msgErr = true; return paintHead(); }
      B = planToBuild(key, d, { id: B.id, name: B.name, notes: B.notes, position: B.position });
      ui.slot = B.items.findIndex((x) => !x); if (ui.slot < 0) ui.slot = 0;
      changed();
      ui.msg = 'Loaded the best-record build. Change anything you like.'; ui.msgErr = false; paintHead();
    } catch (e) { ui.msg = e.message; ui.msgErr = true; paintHead(); }
  }

  // ---- events (delegated) ----
  view.onclick = (e) => {
    const roleEl = e.target.closest('[data-role]');
    if (roleEl) { e.preventDefault(); B.position = roleEl.dataset.role; changed(); if (ui.compare === 'plan') loadCompare(); return; }
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    const act = el.dataset.act, id = Number(el.dataset.id), i = Number(el.dataset.i);
    const R = B.runes;
    switch (act) {
      case 'slot': ui.slot = i; paintSlots(); return;
      case 'remove': e.stopPropagation(); B.items[i] = 0; ui.slot = i; break;
      case 'left': case 'right': {
        e.stopPropagation();
        const j = act === 'left' ? i - 1 : i + 1;
        [B.items[i], B.items[j]] = [B.items[j], B.items[i]]; ui.slot = j; break;
      }
      case 'pick': {
        const it = S.items[id];
        if (it?.boots) B.items = B.items.map((x, k) => (S.items[x]?.boots && k !== ui.slot ? 0 : x)); // one pair of boots
        B.items[ui.slot] = id;
        const next = B.items.findIndex((x) => !x);
        if (next >= 0) ui.slot = next;
        break;
      }
      case 'tier': ui.filter = el.dataset.k; ui.search = ''; $('mk-search').value = ''; paintFilters(); paintPicker(); return;
      case 'stat': ui.stat = ui.stat === el.dataset.k ? '' : el.dataset.k; paintFilters(); paintPicker(); return;
      case 'ptree':
        if (R.primary === id) return;
        R.primary = id; R.picks = [0, 0, 0, 0];
        if (R.secondary === id) { R.secondary = 0; R.subPicks = []; }
        break;
      case 'prune': { const row = rowOf(id); R.picks[row] = R.picks[row] === id ? 0 : id; break; }
      case 'stree': if (R.secondary === id) return; R.secondary = id; R.subPicks = []; break;
      case 'srune': {
        if (R.subPicks.includes(id)) R.subPicks = R.subPicks.filter((x) => x !== id);
        else {
          const same = R.subPicks.findIndex((x) => rowOf(x) === rowOf(id));
          if (same >= 0) R.subPicks[same] = id;
          else { if (R.subPicks.length >= 2) R.subPicks.shift(); R.subPicks.push(id); }
        }
        break;
      }
      case 'shard': R.shards[Number(el.dataset.row)] = id; break;
      case 'spell':
        if (B.spells.includes(id)) B.spells = B.spells.filter((x) => x !== id);
        else { if (B.spells.length >= 2) B.spells.shift(); B.spells.push(id); }
        break;
      case 'save': return save(false);
      case 'saveas': return save(true);
      case 'fill': return fillFromPlan();
      case 'clear': {
        const keep = { id: B.id, name: B.name, notes: B.notes, position: B.position };
        B = normBuild({ ...keep, champion: key }); ui.slot = 0; break;
      }
      default: return;
    }
    changed();
  };
  view.onkeydown = (e) => { const el = e.target.closest('.mk-slot'); if (el && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); el.click(); } };
  $('mk-search').oninput = (e) => { ui.search = e.target.value; paintPicker(); };
  $('mk-level').oninput = (e) => { ui.level = Number(e.target.value); paintStats(); };
  $('mk-compare').onchange = (e) => { ui.compare = e.target.value; loadCompare(); };
  $('mk-name').oninput = (e) => { B.name = e.target.value; ui.dirty = true; history.replaceState(null, '', makerHash(B)); };
  $('mk-notes').oninput = (e) => { B.notes = e.target.value; ui.dirty = true; };

  paintCompareOptions();
  paint();
  scheduleCheck();
}
